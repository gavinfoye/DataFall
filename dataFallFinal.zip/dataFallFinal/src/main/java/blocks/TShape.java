package blocks;

import datafall.Blocks;

public class TShape extends Blocks{
    
    public TShape(){
        super(new int [][] {
            {1,1,1},
            {0,1,0}
            
        
        });
    }
    
}
