package blocks;

import datafall.Blocks;

public class JShape extends Blocks{
    
    public JShape(){
        super(new int [][] {
            {0,1},
            {0,1},
            {1,1}
        
        });
    }
    
}
