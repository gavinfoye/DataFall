package blocks;

import datafall.Blocks;

public class SShape extends Blocks {

    public SShape() {
        super(new int[][]{
            {0, 1, 1},
            {1, 1, 0}});
    }

}
