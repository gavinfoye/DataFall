package blocks;

import datafall.Blocks;

public class ZShape extends Blocks{
    
    public ZShape(){
        super(new int [][] {
            {1,1,0},
            {0,1,1}
        
        
        });
    }
    
}
