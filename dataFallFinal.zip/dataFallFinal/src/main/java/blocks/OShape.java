package blocks;

import datafall.Blocks;

public class OShape extends Blocks {

    public OShape() {
        super(new int[][]{
            {1, 1},
            {1, 1}});
    }

}
