package blocks;

import datafall.Blocks;

public class LShape extends Blocks{
    
    public LShape(){
        super(new int [][] {
            {1,0},
            {1,0},
            {1,1}
         });
    }
    
}