package datafall;

import java.awt.Color;
import java.util.Random;

public class Blocks {

    private RebuildWindow rw;
    private Blocks block;
    private Blocks[] blocks;
    private int[][] shape;
    private Color color;
    public Color rebuilding;
    private Color lineColors;
    private int x, y;
    private int[][][] shapes;
    private int currentRotation;
    public boolean clear = false;
    private Lines line;

    private Color[][] rebuild = new Color[10][10];

    private Color[] availableColors = {color.yellow, color.blue, color.blue, color.blue, color.blue};

    public Blocks(int[][] shape) {

        this.shape = shape;

        initShapes();

        line = new Lines(new int[][]{{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}});
    }

    private void initShapes() {

        shapes = new int[4][][];

        for (int i = 0; i < 4; i++) {
            int r = shape[0].length;
            int c = shape.length;

            shapes[i] = new int[r][c];

            for (int y = 0; y < r; y++) {
                for (int x = 0; x < c; x++) {
                    shapes[i][y][x] = shape[c - x - 1][y];
                }
            }
            shape = shapes[i];
        }

    }

    public void spawn(int gridWidth) {

        Random rand = new Random();

        currentRotation = rand.nextInt(shapes.length);
        shape = shapes[currentRotation];

        y = -getHeight();
        x = rand.nextInt(gridWidth - getWidth());

    }

    public int getX() {
        return x;
    }

    public void setX(int newX) {
        x = newX;
    }

    public int getY() {
        return y;
    }

    public void setY(int newY) {
        y = newY;
    }

    public int[][] getShape() {
        return shape;
    }

    public Color getColor() {
        return color;
    }

    public int getHeight() {
        return shape.length;
    }

    public int getWidth() {
        return shape[0].length;
    }

    public void moveDown() {
        y++;
    }

    public void moveLeft() {
        x--;
    }

    public void moveRight() {
        x++;
    }

    public void rotate() {

        currentRotation++;

        if (currentRotation > 3) {
            currentRotation = 0;
        }

        shape = shapes[currentRotation];

    }

    public void unRotate() {

        currentRotation--;

        if (currentRotation < 0) {
            currentRotation = 3;
        }

        shape = shapes[currentRotation];

    }

    public int getBottom() {
        return y + getHeight();
    }

    public int getLeft() {
        return x;
    }

    public int getRight() {
        return x + getWidth();
    }

    public Color getLineColor() {
        return lineColors;
    }

}
