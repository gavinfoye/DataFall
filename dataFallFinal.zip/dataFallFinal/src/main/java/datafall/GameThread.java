package datafall;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GameThread extends Thread {

    private GameWindow gw;
    private GameScreen gs;
    private RebuildWindow rw;
    private int score;
    private Blocks block;
    private int pause = 1500;

    private volatile boolean isPaused = false;

    public GameThread(GameWindow gw, GameScreen gs, RebuildWindow rw) {
        this.gw = gw;
        this.gs = gs;
        this.rw = rw;

    }

    @Override
    public void run() {

        while (true) {
        
            gw.spawnBlock();
            gs.checkBackground();
            gs.setPix(score);
            gs.setFinalScore(score);

            if (score > 7) {
                pause = 500;

            } else if (score > 4) {
                pause = 1000;

            }

            while (gw.moveBlockDown()) {
                try {
                    Thread.sleep(pause);
                    waitUntilResumed();
                } catch (InterruptedException ex) {
                    
                    return;
                }

            }
            if (gw.blockOutOfBounds()) {

               
                JOptionPane.showMessageDialog(null, "Game Over");

                gs.gameOver(true);
                gs.gameOver(false);

                break;
            }

            //rw.printColors();
            gw.moveBlockToBackground();
            score += gw.clearLines();

            gs.updateScore(score);

        }

    }

    public void pauseGame() throws InterruptedException {
        isPaused = false;
    }

    public void resumeGame() {
        isPaused = true;
    }

    public void pauseAction() {
        System.out.println("paused");
        isPaused = true;
    }

    public synchronized void resumeAction() {
        System.out.println("resumed");
        isPaused = false;
        notifyAll();

    }

    private synchronized void waitUntilResumed() throws InterruptedException {
        while (isPaused) {
            wait();
        }
    }

}
