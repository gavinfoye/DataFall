/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datafall;

import java.awt.Color;
import java.util.Random;

/**
 *
 * @author mac
 */
public class Lines {

    private boolean state;
    private int[][] line;
    private Color color;
    private Color temp;
    public Color lineColors;
    private RebuildWindow rw;
    private int x, y;
    String inColors[] = new String[10];
    int order;

    public Lines(int[][] line) {

        this.line = line;
        //state = false;

    }

    public void spawn(int gridWidth) {

        y = 0;
        x = 0;

        color = lineColors;

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int[][] getLine() {
        return line;
    }

    public Color getColor() {

        return color;
    }

    public int getRow() {
        return line.length;
    }

    public int getCol() {
        return line[0].length;
    }

    public int getHeight() {
        return line.length;
    }

    public int getWidth() {
        return line[0].length;
    }

    public void setLineColor(Color input, int r) {
        
        int order = 0;
        lineColors = input;
        //System.out.println(lineColors);
        
        
        if (lineColors == Color.red) {
            System.out.println("red" + r);
            inColors[r] = "Red";
            
        }

        if (lineColors == Color.blue) {
            System.out.println("blue" + r);
           inColors[r] = "Blue";
              
        }

        if (lineColors == Color.green) {
            System.out.println("green" + r);
            inColors[r]="Green";
            
           
        }
        
        
        
    }

     public void orderAdd() {
       for(int i = 0; i < 10; i ++)
       {
           System.out.println(inColors[i]);
       }
    }
    public void getColorsInput(int number){
    
         order = number;
        //System.out.println(order);
        
        
        
    }
    
    public String getLineColor() {
        
        System.out.println(inColors[1]);
        
        return inColors[1];

    }

    public void setDrawLine(boolean state) {

        this.state = state;

    }

    public boolean getDrawLine() {

        return state;

    }

}
