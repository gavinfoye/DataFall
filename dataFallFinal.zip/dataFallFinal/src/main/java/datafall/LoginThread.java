/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datafall;

import javax.swing.JOptionPane;

/**
 *
 * @author mac
 */
public class LoginThread extends Thread{
    
     private LandingScreen ls;
   
     Login log = new Login();
            
            
    
     public LoginThread(LandingScreen ls, GameScreen gs, RebuildWindow rw) {
         
         this.ls = ls;

    }

    @Override
    public void run() {

        while (true) {
         
            
        }

    }
    
    
}
