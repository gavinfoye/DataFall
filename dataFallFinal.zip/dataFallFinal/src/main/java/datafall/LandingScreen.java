package datafall;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import datafall.Login.*;
import java.awt.Color;
import static java.awt.Color.*;
import java.awt.Desktop;
import java.awt.HeadlessException;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;

public class LandingScreen extends javax.swing.JFrame{

    Connection conn;
    Login log = new Login();

    private int id;
    private boolean state;
    private String name;
    boolean success = false;
   
    /**
     * Creates new form landingScreen
     */
    public LandingScreen() {
        initComponents();
        log.setLoggedinState(log.getloggedInState());

        setDisplay();
        //log.getloggedInState();

        id = 0;
        state = false;
        name = "";

        String URL = "jdbc:mysql://localhost:3306/";
        String DB = "datafall_db";
        String USERNAME = "root";
        String PASSWORD = "";

        conn = null;

        try {
            conn = DriverManager.getConnection(URL + DB, USERNAME, PASSWORD);
            System.out.println("Connected");
        } catch (SQLException e) {
            System.err.println(e);
        }
        saveToServer();
        

    }

        public void saveToServer(){
       /* 
        String uploadURL = "http://localhost:80/";
        String filePath = "src/main/resources//endgameImages/player@gamecom2.jpg";

        
        try {
            
            File uploadFile = new File(filePath);
            
 
            UploadTask task = new UploadTask(uploadURL, uploadFile);
            
            task.execute();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error executing upload task: " + ex.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        */
        
        }

    public void setDisplay() {

        if (log.getloggedInState() == true) {
            if (log.getUserType() == 1) {
                setLoggedinState(log.getloggedInState());
                unsernameInput.setText("");
                unsernameInput.setVisible(false);
                usernameLabel.setVisible(false);
                pwInput.setText("");
                pwInput.setVisible(false);
                passwordLabel.setVisible(false);
                galleryButton.setEnabled(true);
                leaderBoardButton.setEnabled(true);
                playGameButton.setEnabled(true);
                registerButton.setText("About");
                loginButton.setText("Logout");

            } else {
                setLoggedinState(log.getloggedInState());
                unsernameInput.setText("");
                pwInput.setText("");

                playGameButton.setText("Admin");
                playGameButton.setEnabled(true);

                galleryButton.setText("Gallery");
                galleryButton.setEnabled(true);

                leaderBoardButton.setText("Leaderboard");
                leaderBoardButton.setEnabled(true);

                registerButton.setText("Player");
                registerButton.setEnabled(true);

                playGameButton.setEnabled(true);
                loginButton.setText("Logout");

                menuPanel.setBackground(red);

            }
        } else {
            playGameButton.setText("Play Game");
            registerButton.setText("Register");
            loginButton.setText("Login");
            unsernameInput.setText("");
            unsernameInput.setVisible(true);
            usernameLabel.setVisible(true);
            pwInput.setText("");
            pwInput.setVisible(true);
            passwordLabel.setVisible(true);
            galleryButton.setEnabled(false);
            leaderBoardButton.setEnabled(false);
            menuPanel.setBackground(new Color(0, 153, 153));

        }

    }

    public void playGame() {
        if (log.getloggedInState() == true) {

            JOptionPane.showMessageDialog(null, "Lets Go!!");

        } else {

            JOptionPane.showMessageDialog(null, "Starting Offline Game. \nYour "
                    + "score and game image will not be saved. "
                    + "\nPlease Login to avail of these functions");

        }

    }

    public void setLoggedinState(boolean state) {

        this.state = state;

    }

    public boolean getloggedInState() {

        return state;

    }

    public void setUserType(int id) {

        this.id = id;

    }

    public int getUserType() {

        return id;
    }

    public void setUserName(String userName) {

        this.name = userName;

    }

    public String getUserName() {

        return name;
    }

    public boolean success(){
        return success;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        webAppButton = new javax.swing.JButton();
        pwInput = new javax.swing.JPasswordField();
        menuPanel = new javax.swing.JPanel();
        playGameButton = new javax.swing.JButton();
        loginButton = new javax.swing.JButton();
        leaderBoardButton = new javax.swing.JButton();
        galleryButton = new javax.swing.JButton();
        registerButton = new javax.swing.JButton();
        usernameLabel = new javax.swing.JLabel();
        unsernameInput = new javax.swing.JTextField();
        passwordLabel = new javax.swing.JLabel();
        backgroundLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        webAppButton.setText("DataFall Web App");
        webAppButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                webAppButtonActionPerformed(evt);
            }
        });
        getContentPane().add(webAppButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 10, 180, 60));
        getContentPane().add(pwInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, 260, 40));

        menuPanel.setBackground(new java.awt.Color(0, 153, 153));
        menuPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        playGameButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        playGameButton.setText("Play Game");
        playGameButton.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        playGameButton.setOpaque(true);
        playGameButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playGameButtonActionPerformed(evt);
            }
        });

        loginButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        loginButton.setText("Login");
        loginButton.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        loginButton.setOpaque(true);
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        leaderBoardButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        leaderBoardButton.setText("Leaderboards");
        leaderBoardButton.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        leaderBoardButton.setEnabled(false);
        leaderBoardButton.setOpaque(true);
        leaderBoardButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leaderBoardButtonActionPerformed(evt);
            }
        });

        galleryButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        galleryButton.setText("Gallery");
        galleryButton.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        galleryButton.setEnabled(false);
        galleryButton.setOpaque(true);
        galleryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                galleryButtonActionPerformed(evt);
            }
        });

        registerButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        registerButton.setText("Register");
        registerButton.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        registerButton.setOpaque(true);
        registerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(menuPanel);
        menuPanel.setLayout(menuPanelLayout);
        menuPanelLayout.setHorizontalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanelLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(registerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(galleryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playGameButton, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(leaderBoardButton, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );
        menuPanelLayout.setVerticalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPanelLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(playGameButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(leaderBoardButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(galleryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(registerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );

        getContentPane().add(menuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 660));

        usernameLabel.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        usernameLabel.setText("Email:");
        getContentPane().add(usernameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 240, 90, 66));
        getContentPane().add(unsernameInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 260, 259, 35));

        passwordLabel.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        passwordLabel.setText("Password:");
        getContentPane().add(passwordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 310, 144, 66));

        backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/fallback.jpeg"))); // NOI18N
        getContentPane().add(backgroundLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, 1030, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void registerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerButtonActionPerformed
        if (registerButton.getText().equals("Register")) {
            DataFall.toRegistration();
        }
        if (registerButton.getText().equals("About")) {
            DataFall.toAboutFromLanding();
        }
    
    }//GEN-LAST:event_registerButtonActionPerformed

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed

        String email = unsernameInput.getText();
        String password = pwInput.getText();

        if (loginButton.getText().equals("Logout")) {
            log.setLoggedinState(false);
            setLoggedinState(log.getloggedInState());
            registerButton.setText("Register");
            JOptionPane.showMessageDialog(null, "Logout Success");
            setUserName("");
            setDisplay();
        } else {
            
            if (email.isEmpty() && password.isEmpty()) {

                JOptionPane.showMessageDialog(null, "Please input your login details");

            } else {

                try {

                    String login = ("SELECT firstname, user_type_id FROM "
                            + "user_info WHERE email=? and password=?");

                    PreparedStatement prepareStat = (PreparedStatement) conn.prepareStatement(login);

                    prepareStat.setString(1, email);
                    prepareStat.setString(2, password);

                    ResultSet rs = prepareStat.executeQuery();

                    //iterate thrpough database to find required data
                    while (rs.next()) {

                        //get "admin_idetifier code, "0" for user, "1" for admin
                        int userType = Integer.parseInt(rs.getString(2));
                        log.setUserType(userType);
                        log.setLoggedinState(true);
                        setUserName(email);
                        JOptionPane.showMessageDialog(null, "Login Success \n Welcome " + rs.getString(1));
                        success = true;
                        setDisplay();
                    }

           
                    rs.close();
                             
                      
                }//end try
                catch (Exception ex) {

                   JOptionPane.showMessageDialog(null, "Login Error");

                }//end catch
               
            }
            
        }
        
        
    }//GEN-LAST:event_loginButtonActionPerformed

    private void playGameButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playGameButtonActionPerformed
         playGame();
        DataFall.toImage();
       
    }//GEN-LAST:event_playGameButtonActionPerformed

    private void leaderBoardButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leaderBoardButtonActionPerformed
        DataFall.toLeader();
    }//GEN-LAST:event_leaderBoardButtonActionPerformed

    private void galleryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_galleryButtonActionPerformed
        DataFall.toGalleryOptionsFromMenu();
    }//GEN-LAST:event_galleryButtonActionPerformed

    private void webAppButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_webAppButtonActionPerformed
        try {

            String url = "http://localhost/DataFall_Web_App";

            Desktop dt = Desktop.getDesktop();
            URI uri = new URI(url);
            dt.browse(uri.resolve(uri));

        } catch (URISyntaxException ex) {

        } catch (IOException ex) {

        }        // TODO add your handling code here:
    }//GEN-LAST:event_webAppButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])throws SQLException  {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LandingScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LandingScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LandingScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LandingScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LandingScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backgroundLabel;
    private javax.swing.JButton galleryButton;
    private javax.swing.JButton leaderBoardButton;
    private javax.swing.JButton loginButton;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JButton playGameButton;
    private javax.swing.JPasswordField pwInput;
    private javax.swing.JButton registerButton;
    private javax.swing.JTextField unsernameInput;
    private javax.swing.JLabel usernameLabel;
    private javax.swing.JButton webAppButton;
    // End of variables declaration//GEN-END:variables
}
