/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datafall;

/**
 *
 * @author mac
 */
public class Login {
 
    
    private int id;
    private boolean state;
    
public Login(){
     id = 0;
     state = false;
}    


public void setLoggedinState(boolean state){
    
  this.state = state;
  
}
    
public boolean getloggedInState(){
    
    return state;
    
}
   
public void setUserType(int id){
    
  this.id = id;
  
}

public int getUserType(){
    
    return id;
}






}
