package datafall;

import blocks.*;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class GameWindow extends JPanel {

    private GameScreen gs;
    private int gridRows;
    private int gridCols;
    private int gridCellSize;
    private Color[][] background;
    private Color blockColor;
    private int filledCols;
    private Color[] color = new Color[40];
    private Blocks block;
    private Lines line;
    private boolean cleared = false;
    private Blocks[] blocks;
    private Blocks[] blocks2;
    private Color topColor;
    private Color bottomColor;
    private int scoreUp;

    private Color[][] rebuild = new Color[20][10];

    public GameWindow(JPanel gameWindowHold) {

        //gameWindowHold.setVisible(false);
        this.setBounds(gameWindowHold.getBounds());
        this.setBackground(gameWindowHold.getBackground());
        this.setBorder(gameWindowHold.getBorder());

        //gs = new GameScreen();
        line = new Lines(new int[][]{{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}});

        gridSetup(10);

        line.setDrawLine(false);

        scoreUp = 0;

    }

    public void resetBackground() {
        background = new Color[gridRows][gridCols];

    }

    public void resetBlock() {
        spawnBlock();
    }

    public void gridSetup(int cols) {

        gridCols = cols;
        gridCellSize = this.getBounds().width / gridCols;
        gridRows = this.getBounds().height / gridCellSize;

        resetBackground();
        blocks2 = new Blocks[]{new PictureOneBlockOne(),
            new PictureOneBlockTwo(),
            new PictureOneBlockThree(),
            new PictureOneBlockFour(),
            new PictureOneBlockFive(),
            new PictureOneBlockSix(),
            new PictureOneBlockSeven(),
            new PictureOneBlockEight(),
            new PictureOneBlockNine(),
            new PictureOneBlockTen(),
            new PictureOneBlockEleven(),
            new PictureOneBlockTwelve(),
            new PictureOneBlockThirteen(),
            new PictureOneBlockFourteen(),
            new PictureOneBlockFifteen(),
            new PictureOneBlocktSixteen()};

        blocks = new Blocks[]{new IShape(), new JShape(), new TShape(), new ZShape(), new OShape(), new SShape(), new LShape()};

    }

    public void setColorForBlocks(Color top, Color bottom) {

        this.topColor = top;
        this.bottomColor = bottom;

    }

    public Color getTopColor() {
        return topColor;
    }

    public Color getBottomColor() {
        return bottomColor;
    }

    public void spawnBlock() {

        Random rand = new Random();

        block = blocks[rand.nextInt(blocks.length)];

        block.spawn(gridCols);

        //blockColor = Color.blue;
        if (scoreUp >= 0) {
            blockColor = topColor;
        }
        if (scoreUp > 4) {
            blockColor = bottomColor;
        }
    }

    public void resetBlocks() {
        scoreUp = 0;
    }

    public Color getColorForLevel() {
        return blockColor;
    }

    public boolean blockOutOfBounds() {
        if (block.getY() < 0) {
            block = null;
            return true;
        }
        return false;
    }

    public boolean moveBlockDown() {

        if (checkBottom() == false) {

            return false;

        }

        block.moveDown();
        repaint();
        return true;
    }

    public void moveBlockLeft() {
        if (block == null) {
            return;
        }
        if (checkLeft() == false) {
            return;
        }

        block.moveLeft();
        repaint();
    }

    public void moveBlockRight() {
        if (block == null) {
            return;
        }
        if (checkRight() == false) {
            return;
        }

        block.moveRight();
        repaint();
    }

    public void dropBlock() {
        if (block == null) {
            return;
        }
        while (checkBottom()) {
            block.moveDown();
            repaint();
        }
    }

    public void rotateBlock() {
        if (block == null) {
            return;
        }
        block.rotate();

        if (block.getLeft() < 0) {
            block.setX(0);
        }

        if (block.getRight() >= gridCols) {
            block.setX(gridCols - block.getWidth());
        }

        if (block.getBottom() >= gridRows) {
            block.setY(gridRows - block.getHeight());
        }

    }

    private boolean checkBottom() {
        if (block.getBottom() == gridRows) {
            return false;
        }

        int[][] shape = block.getShape();
        int w = block.getWidth();
        int h = block.getHeight();

        for (int col = 0; col < w; col++) {
            for (int row = h - 1; row >= 0; row--) {

                if (shape[row][col] != 0) {

                    int x = col + block.getX();
                    int y = row + block.getY() + 1;

                    if (y < 0) {
                        break;
                    }

                    if (background[y][x] != null) {

                        return false;
                    }

                    break;

                }
            }

        }
        return true;
    }

    private boolean checkLeft() {
        if (block.getLeft() == 0) {

            return false;
        }

        int[][] shape = block.getShape();
        int w = block.getWidth();
        int h = block.getHeight();

        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {

                if (shape[row][col] != 0) {

                    int x = col + block.getX() - 1;
                    int y = row + block.getY();

                    if (y < 0) {
                        break;
                    }

                    if (background[y][x] != null) {

                        return false;
                    }
                    break;

                }
            }

        }
        return true;
    }

    private boolean checkRight() {

        if (block.getRight() == gridCols) {
            return false;
        }

        int[][] shape = block.getShape();
        int w = block.getWidth();
        int h = block.getHeight();

        for (int row = 0; row < h; row++) {
            for (int col = w - 1; col >= 0; col--) {

                if (shape[row][col] != 0) {

                    int x = col + block.getX() + 1;
                    int y = row + block.getY();

                    if (y < 0) {
                        break;
                    }

                    if (background[y][x] != null) {

                        return false;
                    }
                    break;

                }
            }

        }
        return true;
    }

    public int clearLines() {

        boolean lineFilled;
        int linesCleared = 0;
        int filledRow = 0;

        for (int r = gridRows - 1; r >= 0; r--) {

            lineFilled = true;

            for (int c = 0; c < gridCols; c++) {

                if (background[r][c] == null) {

                    lineFilled = false;
                    rebuild(-1, -1);
                    lineCleared(false);
                    break;
                }
            }

            if (lineFilled) {

                filledRow = r;
                System.out.println(filledRow);
                rebuild(filledRow, linesCleared);
                lineCleared(true);
                linesCleared++;
                scoreUp++;
                clearLine(r);
                shiftDown(r);
                clearLine(0);

                r++;

                repaint();
            }
        }

        return linesCleared;
    }

    private void clearLine(int r) {

        for (int i = 0; i < gridCols; i++) {

            background[r][i] = null;
        }
    }

    public void rebuild(int r, int linesCleared) {

        if (r == -1 && linesCleared == -1) {
            //setLineColor(Color.orange, r);
        } else if (r > 0) {
            System.out.println(linesCleared + 1);

            for (int y = 0; y < 10; y++) {

                color[y] = background[r][y];
                //gs.getColorArray(color);

            }

        }
    }

    public void lineCleared(boolean cleared) {
        this.cleared = cleared;
    }

    public boolean getCleared() {
        return cleared;
    }

    public Color getColor1() {

        return color[0];
    }

    public Color getColor2() {

        return color[1];
    }

    public Color getColor3() {
        return color[2];

    }

    public Color getColor4() {

        return color[3];
    }

    public Color getColor5() {

        return color[4];
    }

    public Color getColor6() {

        return color[5];
    }

    public Color getColor7() {

        return color[6];
    }

    public Color getColor8() {

        return color[7];
    }

    public Color getColor9() {

        return color[8];
    }

    public Color getColor10() {

        return color[9];
    }

    private void shiftDown(int r) {

        for (int row = r; row > 0; row--) {

            for (int col = 0; col < gridCols; col++) {

                background[row][col] = background[row - 1][col];
            }

        }
    }

    public void moveBlockToBackground() {

        int[][] shape = block.getShape();
        int h = block.getHeight();
        int w = block.getWidth();

        int xPos = block.getX();
        int yPos = block.getY();

        Color color = getColorForLevel();

        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                if (shape[r][c] == 1) {
                    background[r + yPos][c + xPos] = color;

                }
                //rw.setBackground(color);
            }

        }
    }

    public void drawBlock(Graphics g) {

        int h = block.getHeight();
        int w = block.getWidth();
        Color c = getColorForLevel();
        int[][] shape = block.getShape();

        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {
                if (shape[row][col] == 1) {

                    int x = (block.getX() + col) * gridCellSize;
                    int y = (block.getY() + row) * gridCellSize;

                    drawGridSquare(g, c, x, y);

                }

            }
        }
    }

    public void drawBackground(Graphics g) {

        Color color;

        for (int r = 0; r < gridRows; r++) {
            for (int c = 0; c < gridCols; c++) {
                color = background[r][c];

                if (color != null) {
                    int x = c * gridCellSize;
                    int y = r * gridCellSize;

                    drawGridSquare(g, color, x, y);
                }
            }

        }
    }

    private void drawGridSquare(Graphics g, Color color, int x, int y) {
        g.setColor(color);
        g.fillRect(x, y, gridCellSize, gridCellSize);
        g.setColor(Color.black);
        g.drawRect(x, y, gridCellSize, gridCellSize);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBackground(g);
        drawBlock(g);
    }

}
