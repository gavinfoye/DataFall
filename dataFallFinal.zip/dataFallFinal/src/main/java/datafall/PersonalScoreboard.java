package datafall;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class PersonalScoreboard extends javax.swing.JFrame {

    String username;
    String output = "";
    String name = "";
    String[] result = new String[10];
    Connection conn;

    public PersonalScoreboard() {
        initComponents();

        String URL = "jdbc:mysql://localhost:3306/";
        String DB = "datafall_db";
        String USERNAME = "root";
        String PASSWORD = "";

        conn = null;

        try {
            conn = DriverManager.getConnection(URL + DB, USERNAME, PASSWORD);
            System.out.println("Connected");
        } catch (Exception e) {
            System.err.println(e);
        }

    }

    public void setNameForLeader(String name) {
        this.username = name;
        System.out.println(username);
    }

    public String getEmail() {

        return username;
    }

    public void setLeaderboard() {

        String email = getEmail();
        String score = "";

        output = "Username\t | Score \n";
        for (int i = 0; i < 32; i++) {
            output += "_";

        }

        try {

            String getScores = ("SELECT score FROM leaderboard "
                    + "WHERE email_player=? ORDER BY score DESC");

            PreparedStatement prepareStat = (PreparedStatement) conn.prepareStatement(getScores);

            prepareStat.setString(1, email);

            ResultSet rs = prepareStat.executeQuery();

            int maxNum[] = new int[10];
            int temp = 0;

            for (int x = 0; x < 10; x++) { //iterate thrpough database to find required data
                while (rs.next()) {

                    maxNum[x] = rs.getInt(1);

                    String max = String.valueOf(maxNum[x]);

                    output += "\n\n" + email + "\t |" + max + "/10";

                }
            }

            //close query
            rs.close();
        }//end try
        catch (Exception ex) {

            JOptionPane.showMessageDialog(null, "Data Load Error");

        }//end catch     

        leaderboard.setText(output);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuPanel5 = new javax.swing.JPanel();
        toLEaderboardOptions = new javax.swing.JButton();
        mainMenu = new javax.swing.JButton();
        leaderBoardButton5 = new javax.swing.JButton();
        toCommunityBoard = new javax.swing.JButton();
        registerButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        leaderboard = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        menuPanel5.setBackground(new java.awt.Color(0, 153, 153));
        menuPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        toLEaderboardOptions.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        toLEaderboardOptions.setText("Leaderboards");
        toLEaderboardOptions.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        toLEaderboardOptions.setOpaque(true);
        toLEaderboardOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toLEaderboardOptionsActionPerformed(evt);
            }
        });

        mainMenu.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        mainMenu.setText("Main Menu");
        mainMenu.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        mainMenu.setOpaque(true);
        mainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainMenuActionPerformed(evt);
            }
        });

        leaderBoardButton5.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        leaderBoardButton5.setText("Personal");
        leaderBoardButton5.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        leaderBoardButton5.setEnabled(false);
        leaderBoardButton5.setOpaque(true);

        toCommunityBoard.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        toCommunityBoard.setText("Community");
        toCommunityBoard.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        toCommunityBoard.setOpaque(true);
        toCommunityBoard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toCommunityBoardActionPerformed(evt);
            }
        });

        registerButton5.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        registerButton5.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), javax.swing.BorderFactory.createTitledBorder("")));
        registerButton5.setEnabled(false);
        registerButton5.setOpaque(true);

        javax.swing.GroupLayout menuPanel5Layout = new javax.swing.GroupLayout(menuPanel5);
        menuPanel5.setLayout(menuPanel5Layout);
        menuPanel5Layout.setHorizontalGroup(
            menuPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuPanel5Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(menuPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(registerButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mainMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(toCommunityBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(toLEaderboardOptions, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(leaderBoardButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );
        menuPanel5Layout.setVerticalGroup(
            menuPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPanel5Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(toLEaderboardOptions, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(leaderBoardButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(toCommunityBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(registerButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(mainMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );

        leaderboard.setColumns(20);
        leaderboard.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        leaderboard.setForeground(new java.awt.Color(51, 102, 255));
        leaderboard.setRows(5);
        jScrollPane2.setViewportView(leaderboard);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/fallback.jpeg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(590, 590, 590)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(menuPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(270, 270, 270)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1080, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(210, 210, 210)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(menuPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mainMenuActionPerformed
        DataFall.toMenuFromPersonalScoreboard();
    }//GEN-LAST:event_mainMenuActionPerformed

    private void toLEaderboardOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toLEaderboardOptionsActionPerformed
        DataFall.toLeaderOptionsFromPersonalScoreboard();
    }//GEN-LAST:event_toLEaderboardOptionsActionPerformed

    private void toCommunityBoardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toCommunityBoardActionPerformed
        DataFall.toLeaderCommFromPersonalScoreboard();
    }//GEN-LAST:event_toCommunityBoardActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PersonalScoreboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PersonalScoreboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PersonalScoreboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PersonalScoreboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PersonalScoreboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton leaderBoardButton5;
    private javax.swing.JTextArea leaderboard;
    private javax.swing.JButton mainMenu;
    private javax.swing.JPanel menuPanel5;
    private javax.swing.JButton registerButton5;
    private javax.swing.JButton toCommunityBoard;
    private javax.swing.JButton toLEaderboardOptions;
    // End of variables declaration//GEN-END:variables
}
