
package datafall;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;


public class GameScreen extends javax.swing.JFrame {

    private GameWindow gw;
    private RebuildWindow rw;
    private GameThread gt;
    Color color[] = new Color[10];
    String fact = "";
    String finalLevel = "";
    String username = "";
    int finalScore = 0;
    private String nameForImage = "";
    private String level;
    private Color topColor, bottomColor;
    int timeOnScore = 0;
    Connection conn;
    int entryNum = 0;
    boolean loggedInState;
    private final String CrLf = "\r\n";

    public GameScreen() {

        initComponents();

        gw = new GameWindow(gameWindowHold);
        rw = new RebuildWindow(rebuildWindowHold);

        gameWindowHold.setVisible(false);

        this.add(gw);
        this.add(rw);

        fact = "The concept of packet \nswitching was developed \nby Paul Baran while \nresearching for the \nUS Air Force \nin the early 1960s";

        funFactsWindow.setText("Fun Facts: \n \n" + fact);

        gw.resetBlock();

        initControls();

    }
//get username to be used for scoreboard
    public void setNameForLeader(String name) {
        this.username = name;
        System.out.println(username);
    }

    public String getEmail() {

        return username;
    }
//set block colours dependant on user choice
    public void setColorsBlocks(Color top, Color bottom) {

        this.topColor = top;
        this.bottomColor = bottom;

    }

    public Color getTopColor() {
        return topColor;
    }

    public Color getBottomColor() {
        return bottomColor;
    }

    public void setLoggedInState(boolean loggedIn) {

        this.loggedInState = loggedIn;

    }

    public boolean getLoggedIn() {
        return loggedInState;

    }
//initialise controls
    private void initControls() {

        InputMap im = this.getRootPane().getInputMap();
        ActionMap am = this.getRootPane().getActionMap();

        im.put(KeyStroke.getKeyStroke("RIGHT"), "right");
        im.put(KeyStroke.getKeyStroke("LEFT"), "left");
        im.put(KeyStroke.getKeyStroke("UP"), "up");
        im.put(KeyStroke.getKeyStroke("DOWN"), "down");

        am.put("right", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gw.moveBlockRight();
                System.out.println("RIGHT");
            }
        });

        am.put("left", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gw.moveBlockLeft();
                System.out.println("LEFT");

            }
        });

        am.put("up", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gw.rotateBlock();
                System.out.println("UP");

            }
        });

        am.put("down", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gw.dropBlock();
                System.out.println("DOWN");

            }
        });

    }
//start game and reinitalise screen componets
    public void startGame() {

        initControls();

        gw.setColorForBlocks(topColor, bottomColor);

        gw.resetBlocks();

        gw.resetBackground();

        gt = new GameThread(gw, this, rw);

        gt.start();

        level = "Dial Up";

        updateLevel(level);

        updateScore(0);
//set background image
        backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/level1Backgorund.png")));

        setRebuildExample(topColor, bottomColor);

        resetPix();

        fact = "The concept of packet \nswitching was developed \nby Paul Baran while \nresearching for the \nUS Air Force \nin the early 1960s";
        funFactsWindow.setText("Fun Facts: \n \n" + fact);

        funFactsWindow.setVisible(true);
        scoreTextField.setVisible(true);
        SpeedTextField.setVisible(true);

    }
//set image example dependant on the image the user has chosen
    public void setRebuildExample(Color top, Color bottom) {

        if (top == Color.blue && bottom == Color.yellow) {

            rebuildExample.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rebuildGuide/blueYellow.png")));

        }

        if (top == Color.green && bottom == Color.red) {

            rebuildExample.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rebuildGuide/greenRed.png")));

        }

        if (top == Color.black && bottom == Color.white) {

            rebuildExample.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rebuildGuide/blackWhite.png")));

        }

    }
//check if new colours have been addes from cleared line adn add to array
    public void checkBackground() {

        color[0] = gw.getColor1();
        color[1] = gw.getColor2();
        color[2] = gw.getColor3();
        color[3] = gw.getColor4();
        color[4] = gw.getColor5();
        color[5] = gw.getColor6();
        color[6] = gw.getColor7();
        color[7] = gw.getColor8();
        color[8] = gw.getColor9();
        color[9] = gw.getColor10();

        for (int i = 0; i < 10; i++) {
            System.out.println(color[i]);
        }

    }
//rebuild image in rebuild winodw as scores increase
    public void setPix(int score) {

        int levup = score;

        if (levup == 1) {

            rebuildWindowHold.setBackground(color[0]);
            rebuildWindowHold1.setBackground(color[1]);
            rebuildWindowHold2.setBackground(color[2]);
            rebuildWindowHold3.setBackground(color[3]);
            rebuildWindowHold4.setBackground(color[4]);
            rebuildWindowHold5.setBackground(color[6]);
            rebuildWindowHold6.setBackground(color[6]);
            rebuildWindowHold7.setBackground(color[7]);
            rebuildWindowHold8.setBackground(color[8]);
            rebuildWindowHold9.setBackground(color[9]);

            fact = "Packet switching is \nwhere messages are "
                    + "\nbroken into reasonable \nsize packets that "
                    + "\ncan be switched \nindependently to "
                    + "\ntheir destination.";

        }
        
        if (levup == 2) {
            rebuildWindowHold10.setBackground(color[0]);
            rebuildWindowHold12.setBackground(color[1]);
            rebuildWindowHold13.setBackground(color[2]);
            rebuildWindowHold14.setBackground(color[3]);
            rebuildWindowHold15.setBackground(color[4]);
            rebuildWindowHold16.setBackground(color[6]);
            rebuildWindowHold17.setBackground(color[6]);
            rebuildWindowHold18.setBackground(color[7]);
            rebuildWindowHold19.setBackground(color[8]);
            rebuildWindowHold20.setBackground(color[9]);

        }
        if (levup == 3) {
            if (timeOnScore == 0) {
                backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/level2background.png")));
                updateScore(levup);

            }
            timeOnScore++;

            rebuildWindowHold21.setBackground(color[0]);
            rebuildWindowHold22.setBackground(color[1]);
            rebuildWindowHold23.setBackground(color[2]);
            rebuildWindowHold24.setBackground(color[3]);
            rebuildWindowHold25.setBackground(color[4]);
            rebuildWindowHold26.setBackground(color[6]);
            rebuildWindowHold27.setBackground(color[6]);
            rebuildWindowHold28.setBackground(color[7]);
            rebuildWindowHold29.setBackground(color[8]);
            rebuildWindowHold30.setBackground(color[9]);

            fact = "Packet switching is \nwhere messages are "
                    + "\nbroken into reasonable \nsize packets that "
                    + "\ncan be switched \nindependently to "
                    + "\ntheir destination.";
        }
        if (levup == 4) {
            timeOnScore = 0;
            rebuildWindowHold31.setBackground(color[0]);
            rebuildWindowHold32.setBackground(color[1]);
            rebuildWindowHold33.setBackground(color[2]);
            rebuildWindowHold34.setBackground(color[3]);
            rebuildWindowHold35.setBackground(color[4]);
            rebuildWindowHold36.setBackground(color[6]);
            rebuildWindowHold37.setBackground(color[6]);
            rebuildWindowHold38.setBackground(color[7]);
            rebuildWindowHold39.setBackground(color[8]);
            rebuildWindowHold40.setBackground(color[9]);

        }
        if (levup == 5) {

            if (timeOnScore == 0) {
                backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/level3background.png")));

            }
            timeOnScore++;
            rebuildWindowHold41.setBackground(color[0]);
            rebuildWindowHold42.setBackground(color[1]);
            rebuildWindowHold43.setBackground(color[2]);
            rebuildWindowHold44.setBackground(color[3]);
            rebuildWindowHold45.setBackground(color[4]);
            rebuildWindowHold46.setBackground(color[6]);
            rebuildWindowHold47.setBackground(color[6]);
            rebuildWindowHold48.setBackground(color[7]);
            rebuildWindowHold49.setBackground(color[8]);
            rebuildWindowHold50.setBackground(color[9]);

            updateScore(levup);

        }
        if (levup == 6) {
            rebuildWindowHold51.setBackground(color[0]);
            rebuildWindowHold52.setBackground(color[1]);
            rebuildWindowHold53.setBackground(color[2]);
            rebuildWindowHold54.setBackground(color[3]);
            rebuildWindowHold55.setBackground(color[4]);
            rebuildWindowHold56.setBackground(color[6]);
            rebuildWindowHold57.setBackground(color[6]);
            rebuildWindowHold58.setBackground(color[7]);
            rebuildWindowHold59.setBackground(color[8]);
            rebuildWindowHold60.setBackground(color[9]);
            timeOnScore = 0;
            updateScore(levup);

        }
        if (levup == 7) {

            if (timeOnScore == 0) {
                backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/level4background.png")));
                updateScore(levup);
                timeOnScore++;
            }

            rebuildWindowHold61.setBackground(color[0]);
            rebuildWindowHold62.setBackground(color[1]);
            rebuildWindowHold63.setBackground(color[2]);
            rebuildWindowHold64.setBackground(color[3]);
            rebuildWindowHold65.setBackground(color[4]);
            rebuildWindowHold66.setBackground(color[6]);
            rebuildWindowHold67.setBackground(color[6]);
            rebuildWindowHold68.setBackground(color[7]);
            rebuildWindowHold69.setBackground(color[8]);
            rebuildWindowHold70.setBackground(color[9]);

            fact = "The modern-day internet\n"
                    + "is built and\n"
                    + "operates atop of\n "
                    + "this data transfer\n"
                    + "philosophy through\n"
                    + "different protocols\n"
                    + "such as TCP/IP";

        }
        if (levup == 8) {

            rebuildWindowHold71.setBackground(color[0]);
            rebuildWindowHold72.setBackground(color[1]);
            rebuildWindowHold73.setBackground(color[2]);
            rebuildWindowHold74.setBackground(color[3]);
            rebuildWindowHold75.setBackground(color[4]);
            rebuildWindowHold76.setBackground(color[6]);
            rebuildWindowHold77.setBackground(color[6]);
            rebuildWindowHold78.setBackground(color[7]);
            rebuildWindowHold79.setBackground(color[8]);
            rebuildWindowHold80.setBackground(color[9]);

            updateScore(levup);

        }
        if (levup == 9) {
            rebuildWindowHold81.setBackground(color[0]);
            rebuildWindowHold82.setBackground(color[1]);
            rebuildWindowHold83.setBackground(color[2]);
            rebuildWindowHold84.setBackground(color[3]);
            rebuildWindowHold85.setBackground(color[4]);
            rebuildWindowHold86.setBackground(color[6]);
            rebuildWindowHold87.setBackground(color[6]);
            rebuildWindowHold88.setBackground(color[7]);
            rebuildWindowHold89.setBackground(color[8]);
            rebuildWindowHold90.setBackground(color[9]);
            timeOnScore = 0;
            updateScore(levup);
        }
        if (levup >= 10) {
            setFinalScore(levup);
            updateScore(levup);

            

            rebuildWindowHold91.setBackground(color[0]);
            rebuildWindowHold92.setBackground(color[1]);
            rebuildWindowHold93.setBackground(color[2]);
            rebuildWindowHold94.setBackground(color[3]);
            rebuildWindowHold95.setBackground(color[4]);
            rebuildWindowHold96.setBackground(color[6]);
            rebuildWindowHold97.setBackground(color[6]);
            rebuildWindowHold98.setBackground(color[7]);
            rebuildWindowHold99.setBackground(color[8]);
            rebuildWindowHold100.setBackground(color[9]);
            funFactsWindow.setVisible(false);
            scoreTextField.setVisible(false);
            SpeedTextField.setVisible(false);
            gameOver(true);
         //output message if user is logged in
            updateScore(0);
            if (getLoggedIn() == true) {
                JOptionPane.showMessageDialog(null,
                        "Congratulations, you reassembled the packets.\n"
                        + "Check your gallery to see your new image \n"
                        + "and if it was assembled correctly!");
                saveImageData();
                funFactsWindow.setVisible(true);
                scoreTextField.setVisible(true);
                SpeedTextField.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null,
                        "Congratulations, you reassembled the packets.\n"
                        + "Register and Login to keep records of your scores");
                funFactsWindow.setVisible(true);
                scoreTextField.setVisible(true);
                SpeedTextField.setVisible(true);

            }
            
            
            
            gt.interrupt();
            
            
            gw.resetBackground();
            gw.resetBlock();
            DataFall.gameOver();
            
            gameOver(false);
         
            DataFall.quitGame();

        }

    }

    public void setFinalScore(int score) {
        this.finalScore = score;
    }

    public int getFinalScore() {
        return finalScore;
    }
//reset rebuild window at the end of a game
    public void resetPix() {

        rebuildWindowHold.setBackground(null);
        rebuildWindowHold1.setBackground(null);
        rebuildWindowHold2.setBackground(null);
        rebuildWindowHold3.setBackground(null);
        rebuildWindowHold4.setBackground(null);
        rebuildWindowHold5.setBackground(null);
        rebuildWindowHold6.setBackground(null);
        rebuildWindowHold7.setBackground(null);
        rebuildWindowHold8.setBackground(null);
        rebuildWindowHold9.setBackground(null);

        rebuildWindowHold10.setBackground(null);
        rebuildWindowHold12.setBackground(null);
        rebuildWindowHold13.setBackground(null);
        rebuildWindowHold14.setBackground(null);
        rebuildWindowHold15.setBackground(null);
        rebuildWindowHold16.setBackground(null);
        rebuildWindowHold17.setBackground(null);
        rebuildWindowHold18.setBackground(null);
        rebuildWindowHold19.setBackground(null);
        rebuildWindowHold20.setBackground(null);

        rebuildWindowHold21.setBackground(null);
        rebuildWindowHold22.setBackground(null);
        rebuildWindowHold23.setBackground(null);
        rebuildWindowHold24.setBackground(null);
        rebuildWindowHold25.setBackground(null);
        rebuildWindowHold26.setBackground(null);
        rebuildWindowHold27.setBackground(null);
        rebuildWindowHold28.setBackground(null);
        rebuildWindowHold29.setBackground(null);
        rebuildWindowHold30.setBackground(null);

        rebuildWindowHold31.setBackground(null);
        rebuildWindowHold32.setBackground(null);
        rebuildWindowHold33.setBackground(null);
        rebuildWindowHold34.setBackground(null);
        rebuildWindowHold35.setBackground(null);
        rebuildWindowHold36.setBackground(null);
        rebuildWindowHold37.setBackground(null);
        rebuildWindowHold38.setBackground(null);
        rebuildWindowHold39.setBackground(null);
        rebuildWindowHold40.setBackground(null);

        rebuildWindowHold41.setBackground(null);
        rebuildWindowHold42.setBackground(null);
        rebuildWindowHold43.setBackground(null);
        rebuildWindowHold44.setBackground(null);
        rebuildWindowHold45.setBackground(null);
        rebuildWindowHold46.setBackground(null);
        rebuildWindowHold47.setBackground(null);
        rebuildWindowHold48.setBackground(null);
        rebuildWindowHold49.setBackground(null);
        rebuildWindowHold50.setBackground(null);

        rebuildWindowHold51.setBackground(null);
        rebuildWindowHold52.setBackground(null);
        rebuildWindowHold53.setBackground(null);
        rebuildWindowHold54.setBackground(null);
        rebuildWindowHold55.setBackground(null);
        rebuildWindowHold56.setBackground(null);
        rebuildWindowHold57.setBackground(null);
        rebuildWindowHold58.setBackground(null);
        rebuildWindowHold59.setBackground(null);
        rebuildWindowHold60.setBackground(null);

        rebuildWindowHold61.setBackground(null);
        rebuildWindowHold62.setBackground(null);
        rebuildWindowHold63.setBackground(null);
        rebuildWindowHold64.setBackground(null);
        rebuildWindowHold65.setBackground(null);
        rebuildWindowHold66.setBackground(null);
        rebuildWindowHold67.setBackground(null);
        rebuildWindowHold68.setBackground(null);
        rebuildWindowHold69.setBackground(null);
        rebuildWindowHold70.setBackground(null);

        rebuildWindowHold71.setBackground(null);
        rebuildWindowHold72.setBackground(null);
        rebuildWindowHold73.setBackground(null);
        rebuildWindowHold74.setBackground(null);
        rebuildWindowHold75.setBackground(null);
        rebuildWindowHold76.setBackground(null);
        rebuildWindowHold77.setBackground(null);
        rebuildWindowHold78.setBackground(null);
        rebuildWindowHold79.setBackground(null);
        rebuildWindowHold80.setBackground(null);

        rebuildWindowHold81.setBackground(null);
        rebuildWindowHold82.setBackground(null);
        rebuildWindowHold83.setBackground(null);
        rebuildWindowHold84.setBackground(null);
        rebuildWindowHold85.setBackground(null);
        rebuildWindowHold86.setBackground(null);
        rebuildWindowHold87.setBackground(null);
        rebuildWindowHold88.setBackground(null);
        rebuildWindowHold89.setBackground(null);
        rebuildWindowHold90.setBackground(null);

        rebuildWindowHold91.setBackground(null);
        rebuildWindowHold92.setBackground(null);
        rebuildWindowHold93.setBackground(null);
        rebuildWindowHold94.setBackground(null);
        rebuildWindowHold95.setBackground(null);
        rebuildWindowHold96.setBackground(null);
        rebuildWindowHold97.setBackground(null);
        rebuildWindowHold98.setBackground(null);
        rebuildWindowHold99.setBackground(null);
        rebuildWindowHold100.setBackground(null);
        
    }

    public void updateScore(int score) {

        scoreTextField.setText("Score: " + score);

        if (score >= 0) {

            level = "Dial up";
            updateLevel(level);
            setLevel(level);
            funFactsWindow.setText("Fun Facts: \n \n" + fact);

        }
        if (score > 4) {

            level = "Boradband";
            updateLevel(level);
            setLevel(level);
            funFactsWindow.setText("Fun Facts: \n \n" + fact);
        }
        if (score > 7) {

            level = "Fibre Optic";
            updateLevel(level);
            setLevel(level);
            funFactsWindow.setText("Fun Facts: \n \n" + fact);
        }

    }

    public void updateLevel(String level) {
        SpeedTextField.setText("Speed: " + level);
    }

    
    
 
//pass score data to database at the end of a game
    public void gameOver(boolean over) {

        if (over == true) {
            String lastScore = scoreTextField.getText();
            DataFall.saveToScoreBoard();
            DataFall.gameOver();
            System.out.println(finalScore);

        }

    }

    public void setLevel(String level) {
        finalLevel = level;
    }

    public String getFinalLevel() {
        return finalLevel;
    }

    public void setNameForImage(String userName) {

        this.nameForImage = userName;

    }

    public String getNameForImage() {
        return nameForImage;

    }

    private void saveImageData() {

        String URL = "jdbc:mysql://localhost:3306/";
        String DB = "datafall_db";
        String USERNAME = "root";
        String PASSWORD = "";

        conn = null;

        try {
            conn = DriverManager.getConnection(URL + DB, USERNAME, PASSWORD);
            System.out.println("Connected");
        } catch (Exception e) {
            System.err.println(e);
        }

        try {

            Statement statement = conn.createStatement();

            ResultSet rs = statement.executeQuery("SELECT game_id_rec FROM games_record ORDER BY game_id_rec DESC LIMIT 1");

            //iterate thrpough database to find required data
            while (rs.next()) {

                //get "admin_idetifier code, "0" for user, "1" for admin
                entryNum = Integer.parseInt(rs.getString("game_id_rec"));

                System.out.println(entryNum);
            }

        }//end try//end try
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "issue loading");
        }

        String admin = "admin";

        String email = this.nameForImage;

        int recordNum = entryNum;

        String path = "src/main/resources/";
        String folder = "/endgameImages/";
        String userNameTag = nameForImage;
        userNameTag = userNameTag.replaceAll("[.]", "");
        String fileNumber = Integer.toString(recordNum);
        String extension = ".jpg";
        String imageForComm = userNameTag.concat(fileNumber).concat(extension);

        String imageSaveName = path.concat(folder).concat(userNameTag).concat(fileNumber).concat(extension);

        try {

            PreparedStatement prepareStat = conn.prepareStatement("INSERT into games_record VALUES (?,?,?, default)", Statement.RETURN_GENERATED_KEYS);

            prepareStat.setString(1, imageSaveName);
            prepareStat.setString(2, email);
            prepareStat.setString(3, admin);

            prepareStat.executeUpdate();

            ResultSet tableKeys = prepareStat.getGeneratedKeys();
            tableKeys.next();
            int autoGeneratedID = tableKeys.getInt(1);

            saveImage(rebuildBackgorund, imageSaveName);

            prepareStat = conn.prepareStatement("INSERT into gallery_com VALUES (?,?)");

            prepareStat.setString(1, imageForComm);
            prepareStat.setString(2, nameForImage);

            prepareStat.executeUpdate();

            System.out.println(folder.concat(userNameTag).concat(fileNumber).concat(extension));
            httpConn(path.concat(folder).concat(userNameTag).concat(fileNumber).concat(extension));
        }//end try//end try
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error on insert");
        }//    

    }

    private void saveImage(JPanel rebuildWindow, String file) {

        int recordNum = entryNum;

        /* String path = "src/main/resources/";
        String userNameTag = nameForImage;
        
        userNameTag = userNameTag.replaceAll("[.]", "");
        String fileNumber = Integer.toString(recordNum);
        String extension = ".jpg";*/
        String imageSaveName = file;
        System.out.println(imageSaveName);

        try {

            int w = rebuildWindow.getWidth(), h = rebuildWindow.getHeight();
            BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            Graphics g = image.createGraphics();
            rebuildWindow.setVisible(true);
            rebuildWindow.paint(g);
            //  ImageIO.write(image, "jpeg", new File(""));
            ImageIO.write(image, "jpg", new File(imageSaveName));

        } catch (IOException e) {
            System.err.println(e);
        }
    }

    private void httpConn(String image) {
        URLConnection conn = null;
        BufferedImage img = null;

        OutputStream os = null;
        InputStream is = null;

        try {
            URL url = new URL("http://localhost/DataFall_web_app/post.php");
            System.out.println("url:" + url);
            conn = url.openConnection();
            conn.setDoOutput(true);

            String postData = "";
            //img = ImageIO.read(new File("strawberry.jpg"));
            InputStream imgIs = new BufferedInputStream(new FileInputStream(image));
            byte[] imgData = new byte[imgIs.available()];
            imgIs.read(imgData);

            String message1 = "";
            message1 += "-----------------------------4664151417711" + CrLf;
            message1 += "Content-Disposition: form-data; name=\"uploadedfile\"; filename=" + image
                    + CrLf;
            message1 += "Content-Type: image/jpeg" + CrLf;
            message1 += CrLf;

            // the image is sent between the messages in the multipart message.
            String message2 = "";
            message2 += CrLf + "-----------------------------4664151417711--"
                    + CrLf;

            conn.setRequestProperty("Content-Type",
                    "multipart/form-data; boundary=---------------------------4664151417711");
            // might not need to specify the content-length when sending chunked
            // data.
            conn.setRequestProperty("Content-Length", String.valueOf((message1
                    .length() + message2.length() + imgData.length)));

            System.out.println("open os");
            os = conn.getOutputStream();

            System.out.println(message1);
            os.write(message1.getBytes());

            // SEND THE IMAGE
            int index = 0;
            int size = 1024;
            do {
                System.out.println("write:" + index);
                if ((index + size) > imgData.length) {
                    size = imgData.length - index;
                }
                os.write(imgData, index, size);
                index += size;
            } while (index < imgData.length);
            System.out.println("written:" + index);

            System.out.println(message2);
            os.write(message2.getBytes());
            os.flush();

            System.out.println("open is");
            is = conn.getInputStream();

            char buff = 512;
            int len;
            byte[] data = new byte[buff];
            do {
                System.out.println("READ");
                len = is.read(data);

                if (len > 0) {
                    System.out.println(new String(data, 0, len));
                }
            } while (len > 0);

            System.out.println("DONE");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("Close connection");
            try {
                os.close();
            } catch (Exception e) {
            }
            try {
                is.close();
            } catch (Exception e) {
            }
            try {

            } catch (Exception e) {
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rebuildBackgorund = new javax.swing.JPanel();
        rebuildWindowHold = new javax.swing.JPanel();
        rebuildWindowHold1 = new javax.swing.JPanel();
        rebuildWindowHold2 = new javax.swing.JPanel();
        rebuildWindowHold3 = new javax.swing.JPanel();
        rebuildWindowHold4 = new javax.swing.JPanel();
        rebuildWindowHold5 = new javax.swing.JPanel();
        rebuildWindowHold6 = new javax.swing.JPanel();
        rebuildWindowHold7 = new javax.swing.JPanel();
        rebuildWindowHold8 = new javax.swing.JPanel();
        rebuildWindowHold9 = new javax.swing.JPanel();
        rebuildWindowHold10 = new javax.swing.JPanel();
        rebuildWindowHold12 = new javax.swing.JPanel();
        rebuildWindowHold13 = new javax.swing.JPanel();
        rebuildWindowHold14 = new javax.swing.JPanel();
        rebuildWindowHold15 = new javax.swing.JPanel();
        rebuildWindowHold16 = new javax.swing.JPanel();
        rebuildWindowHold17 = new javax.swing.JPanel();
        rebuildWindowHold18 = new javax.swing.JPanel();
        rebuildWindowHold19 = new javax.swing.JPanel();
        rebuildWindowHold20 = new javax.swing.JPanel();
        rebuildWindowHold21 = new javax.swing.JPanel();
        rebuildWindowHold22 = new javax.swing.JPanel();
        rebuildWindowHold23 = new javax.swing.JPanel();
        rebuildWindowHold24 = new javax.swing.JPanel();
        rebuildWindowHold25 = new javax.swing.JPanel();
        rebuildWindowHold26 = new javax.swing.JPanel();
        rebuildWindowHold27 = new javax.swing.JPanel();
        rebuildWindowHold28 = new javax.swing.JPanel();
        rebuildWindowHold29 = new javax.swing.JPanel();
        rebuildWindowHold30 = new javax.swing.JPanel();
        rebuildWindowHold31 = new javax.swing.JPanel();
        rebuildWindowHold32 = new javax.swing.JPanel();
        rebuildWindowHold33 = new javax.swing.JPanel();
        rebuildWindowHold34 = new javax.swing.JPanel();
        rebuildWindowHold35 = new javax.swing.JPanel();
        rebuildWindowHold36 = new javax.swing.JPanel();
        rebuildWindowHold37 = new javax.swing.JPanel();
        rebuildWindowHold38 = new javax.swing.JPanel();
        rebuildWindowHold39 = new javax.swing.JPanel();
        rebuildWindowHold40 = new javax.swing.JPanel();
        rebuildWindowHold41 = new javax.swing.JPanel();
        rebuildWindowHold42 = new javax.swing.JPanel();
        rebuildWindowHold43 = new javax.swing.JPanel();
        rebuildWindowHold44 = new javax.swing.JPanel();
        rebuildWindowHold45 = new javax.swing.JPanel();
        rebuildWindowHold46 = new javax.swing.JPanel();
        rebuildWindowHold47 = new javax.swing.JPanel();
        rebuildWindowHold48 = new javax.swing.JPanel();
        rebuildWindowHold49 = new javax.swing.JPanel();
        rebuildWindowHold50 = new javax.swing.JPanel();
        rebuildWindowHold51 = new javax.swing.JPanel();
        rebuildWindowHold52 = new javax.swing.JPanel();
        rebuildWindowHold53 = new javax.swing.JPanel();
        rebuildWindowHold54 = new javax.swing.JPanel();
        rebuildWindowHold55 = new javax.swing.JPanel();
        rebuildWindowHold56 = new javax.swing.JPanel();
        rebuildWindowHold57 = new javax.swing.JPanel();
        rebuildWindowHold58 = new javax.swing.JPanel();
        rebuildWindowHold59 = new javax.swing.JPanel();
        rebuildWindowHold60 = new javax.swing.JPanel();
        rebuildWindowHold61 = new javax.swing.JPanel();
        rebuildWindowHold62 = new javax.swing.JPanel();
        rebuildWindowHold63 = new javax.swing.JPanel();
        rebuildWindowHold64 = new javax.swing.JPanel();
        rebuildWindowHold65 = new javax.swing.JPanel();
        rebuildWindowHold66 = new javax.swing.JPanel();
        rebuildWindowHold67 = new javax.swing.JPanel();
        rebuildWindowHold87 = new javax.swing.JPanel();
        rebuildWindowHold68 = new javax.swing.JPanel();
        rebuildWindowHold69 = new javax.swing.JPanel();
        rebuildWindowHold70 = new javax.swing.JPanel();
        rebuildWindowHold71 = new javax.swing.JPanel();
        rebuildWindowHold72 = new javax.swing.JPanel();
        rebuildWindowHold73 = new javax.swing.JPanel();
        rebuildWindowHold74 = new javax.swing.JPanel();
        rebuildWindowHold75 = new javax.swing.JPanel();
        rebuildWindowHold76 = new javax.swing.JPanel();
        rebuildWindowHold77 = new javax.swing.JPanel();
        rebuildWindowHold78 = new javax.swing.JPanel();
        rebuildWindowHold79 = new javax.swing.JPanel();
        rebuildWindowHold80 = new javax.swing.JPanel();
        rebuildWindowHold81 = new javax.swing.JPanel();
        rebuildWindowHold82 = new javax.swing.JPanel();
        rebuildWindowHold83 = new javax.swing.JPanel();
        rebuildWindowHold84 = new javax.swing.JPanel();
        rebuildWindowHold85 = new javax.swing.JPanel();
        rebuildWindowHold86 = new javax.swing.JPanel();
        rebuildWindowHold88 = new javax.swing.JPanel();
        rebuildWindowHold89 = new javax.swing.JPanel();
        rebuildWindowHold90 = new javax.swing.JPanel();
        rebuildWindowHold91 = new javax.swing.JPanel();
        rebuildWindowHold92 = new javax.swing.JPanel();
        rebuildWindowHold93 = new javax.swing.JPanel();
        rebuildWindowHold94 = new javax.swing.JPanel();
        rebuildWindowHold95 = new javax.swing.JPanel();
        rebuildWindowHold96 = new javax.swing.JPanel();
        rebuildWindowHold97 = new javax.swing.JPanel();
        rebuildWindowHold98 = new javax.swing.JPanel();
        rebuildWindowHold99 = new javax.swing.JPanel();
        rebuildWindowHold100 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        quitButton = new javax.swing.JButton();
        pauseButton = new javax.swing.JButton();
        restartButton = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        gameWindowHold = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        scoreTextField = new javax.swing.JTextField();
        rebuildExample = new javax.swing.JLabel();
        SpeedTextField = new javax.swing.JTextField();
        backgroundLabel = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        funFactsWindow = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        rebuildWindowHold.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHoldLayout = new javax.swing.GroupLayout(rebuildWindowHold);
        rebuildWindowHold.setLayout(rebuildWindowHoldLayout);
        rebuildWindowHoldLayout.setHorizontalGroup(
            rebuildWindowHoldLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHoldLayout.setVerticalGroup(
            rebuildWindowHoldLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold1Layout = new javax.swing.GroupLayout(rebuildWindowHold1);
        rebuildWindowHold1.setLayout(rebuildWindowHold1Layout);
        rebuildWindowHold1Layout.setHorizontalGroup(
            rebuildWindowHold1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold1Layout.setVerticalGroup(
            rebuildWindowHold1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold2Layout = new javax.swing.GroupLayout(rebuildWindowHold2);
        rebuildWindowHold2.setLayout(rebuildWindowHold2Layout);
        rebuildWindowHold2Layout.setHorizontalGroup(
            rebuildWindowHold2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold2Layout.setVerticalGroup(
            rebuildWindowHold2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold3Layout = new javax.swing.GroupLayout(rebuildWindowHold3);
        rebuildWindowHold3.setLayout(rebuildWindowHold3Layout);
        rebuildWindowHold3Layout.setHorizontalGroup(
            rebuildWindowHold3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold3Layout.setVerticalGroup(
            rebuildWindowHold3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold4.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold4Layout = new javax.swing.GroupLayout(rebuildWindowHold4);
        rebuildWindowHold4.setLayout(rebuildWindowHold4Layout);
        rebuildWindowHold4Layout.setHorizontalGroup(
            rebuildWindowHold4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold4Layout.setVerticalGroup(
            rebuildWindowHold4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold5.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold5Layout = new javax.swing.GroupLayout(rebuildWindowHold5);
        rebuildWindowHold5.setLayout(rebuildWindowHold5Layout);
        rebuildWindowHold5Layout.setHorizontalGroup(
            rebuildWindowHold5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold5Layout.setVerticalGroup(
            rebuildWindowHold5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold6Layout = new javax.swing.GroupLayout(rebuildWindowHold6);
        rebuildWindowHold6.setLayout(rebuildWindowHold6Layout);
        rebuildWindowHold6Layout.setHorizontalGroup(
            rebuildWindowHold6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold6Layout.setVerticalGroup(
            rebuildWindowHold6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold7.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold7Layout = new javax.swing.GroupLayout(rebuildWindowHold7);
        rebuildWindowHold7.setLayout(rebuildWindowHold7Layout);
        rebuildWindowHold7Layout.setHorizontalGroup(
            rebuildWindowHold7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold7Layout.setVerticalGroup(
            rebuildWindowHold7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold8Layout = new javax.swing.GroupLayout(rebuildWindowHold8);
        rebuildWindowHold8.setLayout(rebuildWindowHold8Layout);
        rebuildWindowHold8Layout.setHorizontalGroup(
            rebuildWindowHold8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold8Layout.setVerticalGroup(
            rebuildWindowHold8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold9.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold9Layout = new javax.swing.GroupLayout(rebuildWindowHold9);
        rebuildWindowHold9.setLayout(rebuildWindowHold9Layout);
        rebuildWindowHold9Layout.setHorizontalGroup(
            rebuildWindowHold9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold9Layout.setVerticalGroup(
            rebuildWindowHold9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold10.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold10Layout = new javax.swing.GroupLayout(rebuildWindowHold10);
        rebuildWindowHold10.setLayout(rebuildWindowHold10Layout);
        rebuildWindowHold10Layout.setHorizontalGroup(
            rebuildWindowHold10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold10Layout.setVerticalGroup(
            rebuildWindowHold10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold12.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold12Layout = new javax.swing.GroupLayout(rebuildWindowHold12);
        rebuildWindowHold12.setLayout(rebuildWindowHold12Layout);
        rebuildWindowHold12Layout.setHorizontalGroup(
            rebuildWindowHold12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold12Layout.setVerticalGroup(
            rebuildWindowHold12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold13.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold13Layout = new javax.swing.GroupLayout(rebuildWindowHold13);
        rebuildWindowHold13.setLayout(rebuildWindowHold13Layout);
        rebuildWindowHold13Layout.setHorizontalGroup(
            rebuildWindowHold13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold13Layout.setVerticalGroup(
            rebuildWindowHold13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold14.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold14Layout = new javax.swing.GroupLayout(rebuildWindowHold14);
        rebuildWindowHold14.setLayout(rebuildWindowHold14Layout);
        rebuildWindowHold14Layout.setHorizontalGroup(
            rebuildWindowHold14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold14Layout.setVerticalGroup(
            rebuildWindowHold14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold15.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold15Layout = new javax.swing.GroupLayout(rebuildWindowHold15);
        rebuildWindowHold15.setLayout(rebuildWindowHold15Layout);
        rebuildWindowHold15Layout.setHorizontalGroup(
            rebuildWindowHold15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold15Layout.setVerticalGroup(
            rebuildWindowHold15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold16.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold16Layout = new javax.swing.GroupLayout(rebuildWindowHold16);
        rebuildWindowHold16.setLayout(rebuildWindowHold16Layout);
        rebuildWindowHold16Layout.setHorizontalGroup(
            rebuildWindowHold16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold16Layout.setVerticalGroup(
            rebuildWindowHold16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold17.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold17Layout = new javax.swing.GroupLayout(rebuildWindowHold17);
        rebuildWindowHold17.setLayout(rebuildWindowHold17Layout);
        rebuildWindowHold17Layout.setHorizontalGroup(
            rebuildWindowHold17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold17Layout.setVerticalGroup(
            rebuildWindowHold17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold18.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold18Layout = new javax.swing.GroupLayout(rebuildWindowHold18);
        rebuildWindowHold18.setLayout(rebuildWindowHold18Layout);
        rebuildWindowHold18Layout.setHorizontalGroup(
            rebuildWindowHold18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold18Layout.setVerticalGroup(
            rebuildWindowHold18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold19.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold19Layout = new javax.swing.GroupLayout(rebuildWindowHold19);
        rebuildWindowHold19.setLayout(rebuildWindowHold19Layout);
        rebuildWindowHold19Layout.setHorizontalGroup(
            rebuildWindowHold19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold19Layout.setVerticalGroup(
            rebuildWindowHold19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold20.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold20Layout = new javax.swing.GroupLayout(rebuildWindowHold20);
        rebuildWindowHold20.setLayout(rebuildWindowHold20Layout);
        rebuildWindowHold20Layout.setHorizontalGroup(
            rebuildWindowHold20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold20Layout.setVerticalGroup(
            rebuildWindowHold20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold21.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold21Layout = new javax.swing.GroupLayout(rebuildWindowHold21);
        rebuildWindowHold21.setLayout(rebuildWindowHold21Layout);
        rebuildWindowHold21Layout.setHorizontalGroup(
            rebuildWindowHold21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold21Layout.setVerticalGroup(
            rebuildWindowHold21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold22.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold22Layout = new javax.swing.GroupLayout(rebuildWindowHold22);
        rebuildWindowHold22.setLayout(rebuildWindowHold22Layout);
        rebuildWindowHold22Layout.setHorizontalGroup(
            rebuildWindowHold22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold22Layout.setVerticalGroup(
            rebuildWindowHold22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold23.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold23Layout = new javax.swing.GroupLayout(rebuildWindowHold23);
        rebuildWindowHold23.setLayout(rebuildWindowHold23Layout);
        rebuildWindowHold23Layout.setHorizontalGroup(
            rebuildWindowHold23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold23Layout.setVerticalGroup(
            rebuildWindowHold23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold24.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold24Layout = new javax.swing.GroupLayout(rebuildWindowHold24);
        rebuildWindowHold24.setLayout(rebuildWindowHold24Layout);
        rebuildWindowHold24Layout.setHorizontalGroup(
            rebuildWindowHold24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold24Layout.setVerticalGroup(
            rebuildWindowHold24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold25.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold25Layout = new javax.swing.GroupLayout(rebuildWindowHold25);
        rebuildWindowHold25.setLayout(rebuildWindowHold25Layout);
        rebuildWindowHold25Layout.setHorizontalGroup(
            rebuildWindowHold25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold25Layout.setVerticalGroup(
            rebuildWindowHold25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold26.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold26Layout = new javax.swing.GroupLayout(rebuildWindowHold26);
        rebuildWindowHold26.setLayout(rebuildWindowHold26Layout);
        rebuildWindowHold26Layout.setHorizontalGroup(
            rebuildWindowHold26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold26Layout.setVerticalGroup(
            rebuildWindowHold26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold27.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold27Layout = new javax.swing.GroupLayout(rebuildWindowHold27);
        rebuildWindowHold27.setLayout(rebuildWindowHold27Layout);
        rebuildWindowHold27Layout.setHorizontalGroup(
            rebuildWindowHold27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold27Layout.setVerticalGroup(
            rebuildWindowHold27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold28.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold28Layout = new javax.swing.GroupLayout(rebuildWindowHold28);
        rebuildWindowHold28.setLayout(rebuildWindowHold28Layout);
        rebuildWindowHold28Layout.setHorizontalGroup(
            rebuildWindowHold28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold28Layout.setVerticalGroup(
            rebuildWindowHold28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold29.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold29Layout = new javax.swing.GroupLayout(rebuildWindowHold29);
        rebuildWindowHold29.setLayout(rebuildWindowHold29Layout);
        rebuildWindowHold29Layout.setHorizontalGroup(
            rebuildWindowHold29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold29Layout.setVerticalGroup(
            rebuildWindowHold29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold30.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold30Layout = new javax.swing.GroupLayout(rebuildWindowHold30);
        rebuildWindowHold30.setLayout(rebuildWindowHold30Layout);
        rebuildWindowHold30Layout.setHorizontalGroup(
            rebuildWindowHold30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold30Layout.setVerticalGroup(
            rebuildWindowHold30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold31.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold31Layout = new javax.swing.GroupLayout(rebuildWindowHold31);
        rebuildWindowHold31.setLayout(rebuildWindowHold31Layout);
        rebuildWindowHold31Layout.setHorizontalGroup(
            rebuildWindowHold31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold31Layout.setVerticalGroup(
            rebuildWindowHold31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold32.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold32Layout = new javax.swing.GroupLayout(rebuildWindowHold32);
        rebuildWindowHold32.setLayout(rebuildWindowHold32Layout);
        rebuildWindowHold32Layout.setHorizontalGroup(
            rebuildWindowHold32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold32Layout.setVerticalGroup(
            rebuildWindowHold32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold33.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold33Layout = new javax.swing.GroupLayout(rebuildWindowHold33);
        rebuildWindowHold33.setLayout(rebuildWindowHold33Layout);
        rebuildWindowHold33Layout.setHorizontalGroup(
            rebuildWindowHold33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold33Layout.setVerticalGroup(
            rebuildWindowHold33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold34.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold34Layout = new javax.swing.GroupLayout(rebuildWindowHold34);
        rebuildWindowHold34.setLayout(rebuildWindowHold34Layout);
        rebuildWindowHold34Layout.setHorizontalGroup(
            rebuildWindowHold34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold34Layout.setVerticalGroup(
            rebuildWindowHold34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold35.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold35Layout = new javax.swing.GroupLayout(rebuildWindowHold35);
        rebuildWindowHold35.setLayout(rebuildWindowHold35Layout);
        rebuildWindowHold35Layout.setHorizontalGroup(
            rebuildWindowHold35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold35Layout.setVerticalGroup(
            rebuildWindowHold35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold36.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold36Layout = new javax.swing.GroupLayout(rebuildWindowHold36);
        rebuildWindowHold36.setLayout(rebuildWindowHold36Layout);
        rebuildWindowHold36Layout.setHorizontalGroup(
            rebuildWindowHold36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold36Layout.setVerticalGroup(
            rebuildWindowHold36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold37.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold37Layout = new javax.swing.GroupLayout(rebuildWindowHold37);
        rebuildWindowHold37.setLayout(rebuildWindowHold37Layout);
        rebuildWindowHold37Layout.setHorizontalGroup(
            rebuildWindowHold37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold37Layout.setVerticalGroup(
            rebuildWindowHold37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold38.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold38Layout = new javax.swing.GroupLayout(rebuildWindowHold38);
        rebuildWindowHold38.setLayout(rebuildWindowHold38Layout);
        rebuildWindowHold38Layout.setHorizontalGroup(
            rebuildWindowHold38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold38Layout.setVerticalGroup(
            rebuildWindowHold38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold39.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold39Layout = new javax.swing.GroupLayout(rebuildWindowHold39);
        rebuildWindowHold39.setLayout(rebuildWindowHold39Layout);
        rebuildWindowHold39Layout.setHorizontalGroup(
            rebuildWindowHold39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold39Layout.setVerticalGroup(
            rebuildWindowHold39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold40.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold40Layout = new javax.swing.GroupLayout(rebuildWindowHold40);
        rebuildWindowHold40.setLayout(rebuildWindowHold40Layout);
        rebuildWindowHold40Layout.setHorizontalGroup(
            rebuildWindowHold40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold40Layout.setVerticalGroup(
            rebuildWindowHold40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold41.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold41Layout = new javax.swing.GroupLayout(rebuildWindowHold41);
        rebuildWindowHold41.setLayout(rebuildWindowHold41Layout);
        rebuildWindowHold41Layout.setHorizontalGroup(
            rebuildWindowHold41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold41Layout.setVerticalGroup(
            rebuildWindowHold41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold42.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold42Layout = new javax.swing.GroupLayout(rebuildWindowHold42);
        rebuildWindowHold42.setLayout(rebuildWindowHold42Layout);
        rebuildWindowHold42Layout.setHorizontalGroup(
            rebuildWindowHold42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold42Layout.setVerticalGroup(
            rebuildWindowHold42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold43.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold43Layout = new javax.swing.GroupLayout(rebuildWindowHold43);
        rebuildWindowHold43.setLayout(rebuildWindowHold43Layout);
        rebuildWindowHold43Layout.setHorizontalGroup(
            rebuildWindowHold43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold43Layout.setVerticalGroup(
            rebuildWindowHold43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold44.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold44Layout = new javax.swing.GroupLayout(rebuildWindowHold44);
        rebuildWindowHold44.setLayout(rebuildWindowHold44Layout);
        rebuildWindowHold44Layout.setHorizontalGroup(
            rebuildWindowHold44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold44Layout.setVerticalGroup(
            rebuildWindowHold44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold45.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold45Layout = new javax.swing.GroupLayout(rebuildWindowHold45);
        rebuildWindowHold45.setLayout(rebuildWindowHold45Layout);
        rebuildWindowHold45Layout.setHorizontalGroup(
            rebuildWindowHold45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold45Layout.setVerticalGroup(
            rebuildWindowHold45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold46.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold46Layout = new javax.swing.GroupLayout(rebuildWindowHold46);
        rebuildWindowHold46.setLayout(rebuildWindowHold46Layout);
        rebuildWindowHold46Layout.setHorizontalGroup(
            rebuildWindowHold46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold46Layout.setVerticalGroup(
            rebuildWindowHold46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold47.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold47Layout = new javax.swing.GroupLayout(rebuildWindowHold47);
        rebuildWindowHold47.setLayout(rebuildWindowHold47Layout);
        rebuildWindowHold47Layout.setHorizontalGroup(
            rebuildWindowHold47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold47Layout.setVerticalGroup(
            rebuildWindowHold47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold48.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold48Layout = new javax.swing.GroupLayout(rebuildWindowHold48);
        rebuildWindowHold48.setLayout(rebuildWindowHold48Layout);
        rebuildWindowHold48Layout.setHorizontalGroup(
            rebuildWindowHold48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold48Layout.setVerticalGroup(
            rebuildWindowHold48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold49.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold49Layout = new javax.swing.GroupLayout(rebuildWindowHold49);
        rebuildWindowHold49.setLayout(rebuildWindowHold49Layout);
        rebuildWindowHold49Layout.setHorizontalGroup(
            rebuildWindowHold49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold49Layout.setVerticalGroup(
            rebuildWindowHold49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold50.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold50Layout = new javax.swing.GroupLayout(rebuildWindowHold50);
        rebuildWindowHold50.setLayout(rebuildWindowHold50Layout);
        rebuildWindowHold50Layout.setHorizontalGroup(
            rebuildWindowHold50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold50Layout.setVerticalGroup(
            rebuildWindowHold50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold51.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold51Layout = new javax.swing.GroupLayout(rebuildWindowHold51);
        rebuildWindowHold51.setLayout(rebuildWindowHold51Layout);
        rebuildWindowHold51Layout.setHorizontalGroup(
            rebuildWindowHold51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold51Layout.setVerticalGroup(
            rebuildWindowHold51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold52.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold52Layout = new javax.swing.GroupLayout(rebuildWindowHold52);
        rebuildWindowHold52.setLayout(rebuildWindowHold52Layout);
        rebuildWindowHold52Layout.setHorizontalGroup(
            rebuildWindowHold52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold52Layout.setVerticalGroup(
            rebuildWindowHold52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold53.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold53Layout = new javax.swing.GroupLayout(rebuildWindowHold53);
        rebuildWindowHold53.setLayout(rebuildWindowHold53Layout);
        rebuildWindowHold53Layout.setHorizontalGroup(
            rebuildWindowHold53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold53Layout.setVerticalGroup(
            rebuildWindowHold53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold54.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold54Layout = new javax.swing.GroupLayout(rebuildWindowHold54);
        rebuildWindowHold54.setLayout(rebuildWindowHold54Layout);
        rebuildWindowHold54Layout.setHorizontalGroup(
            rebuildWindowHold54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold54Layout.setVerticalGroup(
            rebuildWindowHold54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold55.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold55Layout = new javax.swing.GroupLayout(rebuildWindowHold55);
        rebuildWindowHold55.setLayout(rebuildWindowHold55Layout);
        rebuildWindowHold55Layout.setHorizontalGroup(
            rebuildWindowHold55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold55Layout.setVerticalGroup(
            rebuildWindowHold55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold56.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold56Layout = new javax.swing.GroupLayout(rebuildWindowHold56);
        rebuildWindowHold56.setLayout(rebuildWindowHold56Layout);
        rebuildWindowHold56Layout.setHorizontalGroup(
            rebuildWindowHold56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold56Layout.setVerticalGroup(
            rebuildWindowHold56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold57.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold57Layout = new javax.swing.GroupLayout(rebuildWindowHold57);
        rebuildWindowHold57.setLayout(rebuildWindowHold57Layout);
        rebuildWindowHold57Layout.setHorizontalGroup(
            rebuildWindowHold57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold57Layout.setVerticalGroup(
            rebuildWindowHold57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold58.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold58Layout = new javax.swing.GroupLayout(rebuildWindowHold58);
        rebuildWindowHold58.setLayout(rebuildWindowHold58Layout);
        rebuildWindowHold58Layout.setHorizontalGroup(
            rebuildWindowHold58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold58Layout.setVerticalGroup(
            rebuildWindowHold58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold59.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold59Layout = new javax.swing.GroupLayout(rebuildWindowHold59);
        rebuildWindowHold59.setLayout(rebuildWindowHold59Layout);
        rebuildWindowHold59Layout.setHorizontalGroup(
            rebuildWindowHold59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold59Layout.setVerticalGroup(
            rebuildWindowHold59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold60.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold60Layout = new javax.swing.GroupLayout(rebuildWindowHold60);
        rebuildWindowHold60.setLayout(rebuildWindowHold60Layout);
        rebuildWindowHold60Layout.setHorizontalGroup(
            rebuildWindowHold60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold60Layout.setVerticalGroup(
            rebuildWindowHold60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold61.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold61Layout = new javax.swing.GroupLayout(rebuildWindowHold61);
        rebuildWindowHold61.setLayout(rebuildWindowHold61Layout);
        rebuildWindowHold61Layout.setHorizontalGroup(
            rebuildWindowHold61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold61Layout.setVerticalGroup(
            rebuildWindowHold61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold62.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold62Layout = new javax.swing.GroupLayout(rebuildWindowHold62);
        rebuildWindowHold62.setLayout(rebuildWindowHold62Layout);
        rebuildWindowHold62Layout.setHorizontalGroup(
            rebuildWindowHold62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold62Layout.setVerticalGroup(
            rebuildWindowHold62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold63.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold63Layout = new javax.swing.GroupLayout(rebuildWindowHold63);
        rebuildWindowHold63.setLayout(rebuildWindowHold63Layout);
        rebuildWindowHold63Layout.setHorizontalGroup(
            rebuildWindowHold63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold63Layout.setVerticalGroup(
            rebuildWindowHold63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold64.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold64Layout = new javax.swing.GroupLayout(rebuildWindowHold64);
        rebuildWindowHold64.setLayout(rebuildWindowHold64Layout);
        rebuildWindowHold64Layout.setHorizontalGroup(
            rebuildWindowHold64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold64Layout.setVerticalGroup(
            rebuildWindowHold64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold65.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold65Layout = new javax.swing.GroupLayout(rebuildWindowHold65);
        rebuildWindowHold65.setLayout(rebuildWindowHold65Layout);
        rebuildWindowHold65Layout.setHorizontalGroup(
            rebuildWindowHold65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold65Layout.setVerticalGroup(
            rebuildWindowHold65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold66.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold66Layout = new javax.swing.GroupLayout(rebuildWindowHold66);
        rebuildWindowHold66.setLayout(rebuildWindowHold66Layout);
        rebuildWindowHold66Layout.setHorizontalGroup(
            rebuildWindowHold66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold66Layout.setVerticalGroup(
            rebuildWindowHold66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold67.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold67Layout = new javax.swing.GroupLayout(rebuildWindowHold67);
        rebuildWindowHold67.setLayout(rebuildWindowHold67Layout);
        rebuildWindowHold67Layout.setHorizontalGroup(
            rebuildWindowHold67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold67Layout.setVerticalGroup(
            rebuildWindowHold67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold87.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold87Layout = new javax.swing.GroupLayout(rebuildWindowHold87);
        rebuildWindowHold87.setLayout(rebuildWindowHold87Layout);
        rebuildWindowHold87Layout.setHorizontalGroup(
            rebuildWindowHold87Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold87Layout.setVerticalGroup(
            rebuildWindowHold87Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold68.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold68Layout = new javax.swing.GroupLayout(rebuildWindowHold68);
        rebuildWindowHold68.setLayout(rebuildWindowHold68Layout);
        rebuildWindowHold68Layout.setHorizontalGroup(
            rebuildWindowHold68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold68Layout.setVerticalGroup(
            rebuildWindowHold68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold69.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold69Layout = new javax.swing.GroupLayout(rebuildWindowHold69);
        rebuildWindowHold69.setLayout(rebuildWindowHold69Layout);
        rebuildWindowHold69Layout.setHorizontalGroup(
            rebuildWindowHold69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold69Layout.setVerticalGroup(
            rebuildWindowHold69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold70.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold70Layout = new javax.swing.GroupLayout(rebuildWindowHold70);
        rebuildWindowHold70.setLayout(rebuildWindowHold70Layout);
        rebuildWindowHold70Layout.setHorizontalGroup(
            rebuildWindowHold70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold70Layout.setVerticalGroup(
            rebuildWindowHold70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold71.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold71Layout = new javax.swing.GroupLayout(rebuildWindowHold71);
        rebuildWindowHold71.setLayout(rebuildWindowHold71Layout);
        rebuildWindowHold71Layout.setHorizontalGroup(
            rebuildWindowHold71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold71Layout.setVerticalGroup(
            rebuildWindowHold71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold72.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold72Layout = new javax.swing.GroupLayout(rebuildWindowHold72);
        rebuildWindowHold72.setLayout(rebuildWindowHold72Layout);
        rebuildWindowHold72Layout.setHorizontalGroup(
            rebuildWindowHold72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold72Layout.setVerticalGroup(
            rebuildWindowHold72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold73.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold73Layout = new javax.swing.GroupLayout(rebuildWindowHold73);
        rebuildWindowHold73.setLayout(rebuildWindowHold73Layout);
        rebuildWindowHold73Layout.setHorizontalGroup(
            rebuildWindowHold73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold73Layout.setVerticalGroup(
            rebuildWindowHold73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold74.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold74Layout = new javax.swing.GroupLayout(rebuildWindowHold74);
        rebuildWindowHold74.setLayout(rebuildWindowHold74Layout);
        rebuildWindowHold74Layout.setHorizontalGroup(
            rebuildWindowHold74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold74Layout.setVerticalGroup(
            rebuildWindowHold74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold75.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold75Layout = new javax.swing.GroupLayout(rebuildWindowHold75);
        rebuildWindowHold75.setLayout(rebuildWindowHold75Layout);
        rebuildWindowHold75Layout.setHorizontalGroup(
            rebuildWindowHold75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold75Layout.setVerticalGroup(
            rebuildWindowHold75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold76.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold76Layout = new javax.swing.GroupLayout(rebuildWindowHold76);
        rebuildWindowHold76.setLayout(rebuildWindowHold76Layout);
        rebuildWindowHold76Layout.setHorizontalGroup(
            rebuildWindowHold76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold76Layout.setVerticalGroup(
            rebuildWindowHold76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold77.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold77Layout = new javax.swing.GroupLayout(rebuildWindowHold77);
        rebuildWindowHold77.setLayout(rebuildWindowHold77Layout);
        rebuildWindowHold77Layout.setHorizontalGroup(
            rebuildWindowHold77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold77Layout.setVerticalGroup(
            rebuildWindowHold77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold78.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold78Layout = new javax.swing.GroupLayout(rebuildWindowHold78);
        rebuildWindowHold78.setLayout(rebuildWindowHold78Layout);
        rebuildWindowHold78Layout.setHorizontalGroup(
            rebuildWindowHold78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold78Layout.setVerticalGroup(
            rebuildWindowHold78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold79.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold79Layout = new javax.swing.GroupLayout(rebuildWindowHold79);
        rebuildWindowHold79.setLayout(rebuildWindowHold79Layout);
        rebuildWindowHold79Layout.setHorizontalGroup(
            rebuildWindowHold79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold79Layout.setVerticalGroup(
            rebuildWindowHold79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold80.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold80Layout = new javax.swing.GroupLayout(rebuildWindowHold80);
        rebuildWindowHold80.setLayout(rebuildWindowHold80Layout);
        rebuildWindowHold80Layout.setHorizontalGroup(
            rebuildWindowHold80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold80Layout.setVerticalGroup(
            rebuildWindowHold80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold81.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold81Layout = new javax.swing.GroupLayout(rebuildWindowHold81);
        rebuildWindowHold81.setLayout(rebuildWindowHold81Layout);
        rebuildWindowHold81Layout.setHorizontalGroup(
            rebuildWindowHold81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold81Layout.setVerticalGroup(
            rebuildWindowHold81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold82.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold82Layout = new javax.swing.GroupLayout(rebuildWindowHold82);
        rebuildWindowHold82.setLayout(rebuildWindowHold82Layout);
        rebuildWindowHold82Layout.setHorizontalGroup(
            rebuildWindowHold82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold82Layout.setVerticalGroup(
            rebuildWindowHold82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold83.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold83Layout = new javax.swing.GroupLayout(rebuildWindowHold83);
        rebuildWindowHold83.setLayout(rebuildWindowHold83Layout);
        rebuildWindowHold83Layout.setHorizontalGroup(
            rebuildWindowHold83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold83Layout.setVerticalGroup(
            rebuildWindowHold83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold84.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold84Layout = new javax.swing.GroupLayout(rebuildWindowHold84);
        rebuildWindowHold84.setLayout(rebuildWindowHold84Layout);
        rebuildWindowHold84Layout.setHorizontalGroup(
            rebuildWindowHold84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold84Layout.setVerticalGroup(
            rebuildWindowHold84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold85.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold85Layout = new javax.swing.GroupLayout(rebuildWindowHold85);
        rebuildWindowHold85.setLayout(rebuildWindowHold85Layout);
        rebuildWindowHold85Layout.setHorizontalGroup(
            rebuildWindowHold85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold85Layout.setVerticalGroup(
            rebuildWindowHold85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold86.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold86Layout = new javax.swing.GroupLayout(rebuildWindowHold86);
        rebuildWindowHold86.setLayout(rebuildWindowHold86Layout);
        rebuildWindowHold86Layout.setHorizontalGroup(
            rebuildWindowHold86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold86Layout.setVerticalGroup(
            rebuildWindowHold86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold88.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold88Layout = new javax.swing.GroupLayout(rebuildWindowHold88);
        rebuildWindowHold88.setLayout(rebuildWindowHold88Layout);
        rebuildWindowHold88Layout.setHorizontalGroup(
            rebuildWindowHold88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold88Layout.setVerticalGroup(
            rebuildWindowHold88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold89.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold89Layout = new javax.swing.GroupLayout(rebuildWindowHold89);
        rebuildWindowHold89.setLayout(rebuildWindowHold89Layout);
        rebuildWindowHold89Layout.setHorizontalGroup(
            rebuildWindowHold89Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold89Layout.setVerticalGroup(
            rebuildWindowHold89Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold90.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold90Layout = new javax.swing.GroupLayout(rebuildWindowHold90);
        rebuildWindowHold90.setLayout(rebuildWindowHold90Layout);
        rebuildWindowHold90Layout.setHorizontalGroup(
            rebuildWindowHold90Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold90Layout.setVerticalGroup(
            rebuildWindowHold90Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold91.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold91Layout = new javax.swing.GroupLayout(rebuildWindowHold91);
        rebuildWindowHold91.setLayout(rebuildWindowHold91Layout);
        rebuildWindowHold91Layout.setHorizontalGroup(
            rebuildWindowHold91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold91Layout.setVerticalGroup(
            rebuildWindowHold91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold92.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold92Layout = new javax.swing.GroupLayout(rebuildWindowHold92);
        rebuildWindowHold92.setLayout(rebuildWindowHold92Layout);
        rebuildWindowHold92Layout.setHorizontalGroup(
            rebuildWindowHold92Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold92Layout.setVerticalGroup(
            rebuildWindowHold92Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold93.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold93Layout = new javax.swing.GroupLayout(rebuildWindowHold93);
        rebuildWindowHold93.setLayout(rebuildWindowHold93Layout);
        rebuildWindowHold93Layout.setHorizontalGroup(
            rebuildWindowHold93Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold93Layout.setVerticalGroup(
            rebuildWindowHold93Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold94.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold94Layout = new javax.swing.GroupLayout(rebuildWindowHold94);
        rebuildWindowHold94.setLayout(rebuildWindowHold94Layout);
        rebuildWindowHold94Layout.setHorizontalGroup(
            rebuildWindowHold94Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold94Layout.setVerticalGroup(
            rebuildWindowHold94Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold95.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold95Layout = new javax.swing.GroupLayout(rebuildWindowHold95);
        rebuildWindowHold95.setLayout(rebuildWindowHold95Layout);
        rebuildWindowHold95Layout.setHorizontalGroup(
            rebuildWindowHold95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold95Layout.setVerticalGroup(
            rebuildWindowHold95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold96.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold96Layout = new javax.swing.GroupLayout(rebuildWindowHold96);
        rebuildWindowHold96.setLayout(rebuildWindowHold96Layout);
        rebuildWindowHold96Layout.setHorizontalGroup(
            rebuildWindowHold96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold96Layout.setVerticalGroup(
            rebuildWindowHold96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold97.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold97Layout = new javax.swing.GroupLayout(rebuildWindowHold97);
        rebuildWindowHold97.setLayout(rebuildWindowHold97Layout);
        rebuildWindowHold97Layout.setHorizontalGroup(
            rebuildWindowHold97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold97Layout.setVerticalGroup(
            rebuildWindowHold97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold98.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold98Layout = new javax.swing.GroupLayout(rebuildWindowHold98);
        rebuildWindowHold98.setLayout(rebuildWindowHold98Layout);
        rebuildWindowHold98Layout.setHorizontalGroup(
            rebuildWindowHold98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold98Layout.setVerticalGroup(
            rebuildWindowHold98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold99.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold99Layout = new javax.swing.GroupLayout(rebuildWindowHold99);
        rebuildWindowHold99.setLayout(rebuildWindowHold99Layout);
        rebuildWindowHold99Layout.setHorizontalGroup(
            rebuildWindowHold99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold99Layout.setVerticalGroup(
            rebuildWindowHold99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        rebuildWindowHold100.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout rebuildWindowHold100Layout = new javax.swing.GroupLayout(rebuildWindowHold100);
        rebuildWindowHold100.setLayout(rebuildWindowHold100Layout);
        rebuildWindowHold100Layout.setHorizontalGroup(
            rebuildWindowHold100Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        rebuildWindowHold100Layout.setVerticalGroup(
            rebuildWindowHold100Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout rebuildBackgorundLayout = new javax.swing.GroupLayout(rebuildBackgorund);
        rebuildBackgorund.setLayout(rebuildBackgorundLayout);
        rebuildBackgorundLayout.setHorizontalGroup(
            rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
            .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold48, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold49, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold52, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold53, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold54, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold55, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold56, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold57, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold58, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold59, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold63, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold65, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold66, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold67, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold68, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold69, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold70, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold71, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold72, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold73, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold74, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold75, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold76, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold77, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold78, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold79, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold80, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold84, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold85, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold86, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold87, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold88, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold89, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold90, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                            .addComponent(rebuildWindowHold91, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold92, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold93, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold94, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold95, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold96, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold97, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold99, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rebuildWindowHold100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        rebuildBackgorundLayout.setVerticalGroup(
            rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
            .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(rebuildBackgorundLayout.createSequentialGroup()
                    .addGap(0, 5, Short.MAX_VALUE)
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold48, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold49, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold50, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold52, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold53, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold54, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold55, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold56, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold57, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold58, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold59, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold63, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold65, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold66, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold67, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold68, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold69, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold70, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold71, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold72, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold73, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold74, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold75, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold76, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold77, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold78, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold79, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold80, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold84, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold85, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold86, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold87, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold88, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold89, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold90, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rebuildBackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rebuildWindowHold91, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold92, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold93, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold94, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold95, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold96, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold97, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold99, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rebuildWindowHold100, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 5, Short.MAX_VALUE)))
        );

        quitButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        quitButton.setForeground(new java.awt.Color(0, 204, 0));
        quitButton.setText("Quit");
        quitButton.setFocusable(false);
        quitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitButtonActionPerformed(evt);
            }
        });

        pauseButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        pauseButton.setForeground(new java.awt.Color(0, 204, 0));
        pauseButton.setText("Pause");
        pauseButton.setFocusable(false);
        pauseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pauseButtonActionPerformed(evt);
            }
        });

        restartButton.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        restartButton.setForeground(new java.awt.Color(0, 204, 0));
        restartButton.setText("Restart");
        restartButton.setFocusable(false);
        restartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartButtonActionPerformed(evt);
            }
        });

        jLabel20.setToolTipText("");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pauseButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addGap(28, 28, 28)
                .addComponent(restartButton)
                .addGap(18, 18, 18)
                .addComponent(quitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(restartButton)
                        .addComponent(pauseButton)
                        .addComponent(quitButton))
                    .addComponent(jLabel20))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        gameWindowHold.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout gameWindowHoldLayout = new javax.swing.GroupLayout(gameWindowHold);
        gameWindowHold.setLayout(gameWindowHoldLayout);
        gameWindowHoldLayout.setHorizontalGroup(
            gameWindowHoldLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gameWindowHoldLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel22)
                .addContainerGap(315, Short.MAX_VALUE))
        );
        gameWindowHoldLayout.setVerticalGroup(
            gameWindowHoldLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gameWindowHoldLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel22)
                .addContainerGap(433, Short.MAX_VALUE))
        );

        scoreTextField.setEditable(false);
        scoreTextField.setBackground(new java.awt.Color(0, 0, 0));
        scoreTextField.setFont(new java.awt.Font("Courier", 0, 18)); // NOI18N
        scoreTextField.setForeground(new java.awt.Color(51, 153, 0));
        scoreTextField.setText("Score: 0");
        scoreTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scoreTextFieldActionPerformed(evt);
            }
        });

        SpeedTextField.setEditable(false);
        SpeedTextField.setBackground(new java.awt.Color(0, 0, 0));
        SpeedTextField.setFont(new java.awt.Font("Courier", 0, 18)); // NOI18N
        SpeedTextField.setForeground(new java.awt.Color(51, 153, 0));
        SpeedTextField.setText("Speed:");
        SpeedTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SpeedTextFieldActionPerformed(evt);
            }
        });

        backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/level1Backgorund.png"))); // NOI18N

        funFactsWindow.setEditable(false);
        funFactsWindow.setBackground(new java.awt.Color(0, 0, 0));
        funFactsWindow.setColumns(20);
        funFactsWindow.setFont(new java.awt.Font("Courier", 0, 24)); // NOI18N
        funFactsWindow.setForeground(new java.awt.Color(0, 153, 0));
        funFactsWindow.setRows(5);
        funFactsWindow.setText("Fun Facts:");
        funFactsWindow.setAutoscrolls(false);
        jScrollPane5.setViewportView(funFactsWindow);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(370, 370, 370)
                .addComponent(scoreTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(400, 400, 400)
                .addComponent(gameWindowHold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(rebuildExample, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(890, 890, 890)
                .addComponent(rebuildBackgorund, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(570, 570, 570)
                .addComponent(SpeedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(800, 800, 800)
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(backgroundLabel)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(scoreTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(gameWindowHold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(430, 430, 430)
                .addComponent(rebuildExample, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(210, 210, 210)
                .addComponent(rebuildBackgorund, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(SpeedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(520, 520, 520)
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(backgroundLabel)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void scoreTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scoreTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_scoreTextFieldActionPerformed

    private void SpeedTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SpeedTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SpeedTextFieldActionPerformed

    private void pauseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pauseButtonActionPerformed
        if (pauseButton.getText() == "Pause") {
            pauseButton.setText("Resume");
            gt.pauseAction();
        } else if (pauseButton.getText() == "Resume") {
            pauseButton.setText("Pause");
            gt.resumeAction();

        }
    }//GEN-LAST:event_pauseButtonActionPerformed

    private void quitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitButtonActionPerformed

        gt.interrupt();
        updateScore(0);
        gw.blockOutOfBounds();
       
        gw.resetBackground();
        gw.resetBlock();
DataFall.gameOver();
        DataFall.quitGame();
    }//GEN-LAST:event_quitButtonActionPerformed

    private void restartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restartButtonActionPerformed

        gt.interrupt();
        gw.resetBackground();
        fact = "The concept of packet \nswitching was developed \nby Paul Baran while \nresearching for the \nUS Air Force \nin the early 1960s";
        funFactsWindow.setText("Fun Facts: \n \n" + fact);
        gw.resetBlock();
        startGame();

    }//GEN-LAST:event_restartButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField SpeedTextField;
    private javax.swing.JLabel backgroundLabel;
    private javax.swing.JTextArea funFactsWindow;
    private javax.swing.JPanel gameWindowHold;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JButton pauseButton;
    private javax.swing.JButton quitButton;
    private javax.swing.JPanel rebuildBackgorund;
    private javax.swing.JLabel rebuildExample;
    private javax.swing.JPanel rebuildWindowHold;
    private javax.swing.JPanel rebuildWindowHold1;
    private javax.swing.JPanel rebuildWindowHold10;
    private javax.swing.JPanel rebuildWindowHold100;
    private javax.swing.JPanel rebuildWindowHold12;
    private javax.swing.JPanel rebuildWindowHold13;
    private javax.swing.JPanel rebuildWindowHold14;
    private javax.swing.JPanel rebuildWindowHold15;
    private javax.swing.JPanel rebuildWindowHold16;
    private javax.swing.JPanel rebuildWindowHold17;
    private javax.swing.JPanel rebuildWindowHold18;
    private javax.swing.JPanel rebuildWindowHold19;
    private javax.swing.JPanel rebuildWindowHold2;
    private javax.swing.JPanel rebuildWindowHold20;
    private javax.swing.JPanel rebuildWindowHold21;
    private javax.swing.JPanel rebuildWindowHold22;
    private javax.swing.JPanel rebuildWindowHold23;
    private javax.swing.JPanel rebuildWindowHold24;
    private javax.swing.JPanel rebuildWindowHold25;
    private javax.swing.JPanel rebuildWindowHold26;
    private javax.swing.JPanel rebuildWindowHold27;
    private javax.swing.JPanel rebuildWindowHold28;
    private javax.swing.JPanel rebuildWindowHold29;
    private javax.swing.JPanel rebuildWindowHold3;
    private javax.swing.JPanel rebuildWindowHold30;
    private javax.swing.JPanel rebuildWindowHold31;
    private javax.swing.JPanel rebuildWindowHold32;
    private javax.swing.JPanel rebuildWindowHold33;
    private javax.swing.JPanel rebuildWindowHold34;
    private javax.swing.JPanel rebuildWindowHold35;
    private javax.swing.JPanel rebuildWindowHold36;
    private javax.swing.JPanel rebuildWindowHold37;
    private javax.swing.JPanel rebuildWindowHold38;
    private javax.swing.JPanel rebuildWindowHold39;
    private javax.swing.JPanel rebuildWindowHold4;
    private javax.swing.JPanel rebuildWindowHold40;
    private javax.swing.JPanel rebuildWindowHold41;
    private javax.swing.JPanel rebuildWindowHold42;
    private javax.swing.JPanel rebuildWindowHold43;
    private javax.swing.JPanel rebuildWindowHold44;
    private javax.swing.JPanel rebuildWindowHold45;
    private javax.swing.JPanel rebuildWindowHold46;
    private javax.swing.JPanel rebuildWindowHold47;
    private javax.swing.JPanel rebuildWindowHold48;
    private javax.swing.JPanel rebuildWindowHold49;
    private javax.swing.JPanel rebuildWindowHold5;
    private javax.swing.JPanel rebuildWindowHold50;
    private javax.swing.JPanel rebuildWindowHold51;
    private javax.swing.JPanel rebuildWindowHold52;
    private javax.swing.JPanel rebuildWindowHold53;
    private javax.swing.JPanel rebuildWindowHold54;
    private javax.swing.JPanel rebuildWindowHold55;
    private javax.swing.JPanel rebuildWindowHold56;
    private javax.swing.JPanel rebuildWindowHold57;
    private javax.swing.JPanel rebuildWindowHold58;
    private javax.swing.JPanel rebuildWindowHold59;
    private javax.swing.JPanel rebuildWindowHold6;
    private javax.swing.JPanel rebuildWindowHold60;
    private javax.swing.JPanel rebuildWindowHold61;
    private javax.swing.JPanel rebuildWindowHold62;
    private javax.swing.JPanel rebuildWindowHold63;
    private javax.swing.JPanel rebuildWindowHold64;
    private javax.swing.JPanel rebuildWindowHold65;
    private javax.swing.JPanel rebuildWindowHold66;
    private javax.swing.JPanel rebuildWindowHold67;
    private javax.swing.JPanel rebuildWindowHold68;
    private javax.swing.JPanel rebuildWindowHold69;
    private javax.swing.JPanel rebuildWindowHold7;
    private javax.swing.JPanel rebuildWindowHold70;
    private javax.swing.JPanel rebuildWindowHold71;
    private javax.swing.JPanel rebuildWindowHold72;
    private javax.swing.JPanel rebuildWindowHold73;
    private javax.swing.JPanel rebuildWindowHold74;
    private javax.swing.JPanel rebuildWindowHold75;
    private javax.swing.JPanel rebuildWindowHold76;
    private javax.swing.JPanel rebuildWindowHold77;
    private javax.swing.JPanel rebuildWindowHold78;
    private javax.swing.JPanel rebuildWindowHold79;
    private javax.swing.JPanel rebuildWindowHold8;
    private javax.swing.JPanel rebuildWindowHold80;
    private javax.swing.JPanel rebuildWindowHold81;
    private javax.swing.JPanel rebuildWindowHold82;
    private javax.swing.JPanel rebuildWindowHold83;
    private javax.swing.JPanel rebuildWindowHold84;
    private javax.swing.JPanel rebuildWindowHold85;
    private javax.swing.JPanel rebuildWindowHold86;
    private javax.swing.JPanel rebuildWindowHold87;
    private javax.swing.JPanel rebuildWindowHold88;
    private javax.swing.JPanel rebuildWindowHold89;
    private javax.swing.JPanel rebuildWindowHold9;
    private javax.swing.JPanel rebuildWindowHold90;
    private javax.swing.JPanel rebuildWindowHold91;
    private javax.swing.JPanel rebuildWindowHold92;
    private javax.swing.JPanel rebuildWindowHold93;
    private javax.swing.JPanel rebuildWindowHold94;
    private javax.swing.JPanel rebuildWindowHold95;
    private javax.swing.JPanel rebuildWindowHold96;
    private javax.swing.JPanel rebuildWindowHold97;
    private javax.swing.JPanel rebuildWindowHold98;
    private javax.swing.JPanel rebuildWindowHold99;
    private javax.swing.JButton restartButton;
    private javax.swing.JTextField scoreTextField;
    // End of variables declaration//GEN-END:variables
}
