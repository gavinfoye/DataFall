package datafall;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;


public class ImageSelectWindow extends JPanel {

    private GameScreen gs;
    private int gridRows;
    private int gridCols;
    private int gridCellSize;
    private Color[][] background;
    private Color[][] image;
    private int filledCols;
    private Color[] color = new Color[90];
    private Blocks block;
    private Lines line;
    private boolean cleared = false;
    private Blocks[] blocks;

    public Color topColor;
    public Color bottomColor;

    private int picture2[][] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 2, 2, 1, 1, 1, 1},
    {1, 1, 1, 2, 2, 2, 2, 1, 1, 1},
    {1, 1, 2, 2, 2, 2, 2, 2, 1, 1},
    {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
    {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
    {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
    {1, 1, 1, 2, 2, 2, 2, 1, 1, 1},
    {1, 1, 1, 1, 2, 2, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},};

    private int picture[][] = {
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};

    public ImageSelectWindow(JPanel imageSelectHold, int cols) {

        imageSelectHold.setVisible(false);
        this.setBounds(imageSelectHold.getBounds());
        this.setBackground(imageSelectHold.getBackground());
        this.setBorder(imageSelectHold.getBorder());

        gridCols = cols;
        gridCellSize = this.getBounds().width / gridCols;
        gridRows = this.getBounds().height / gridCellSize;
    }

    public void selectionSetColors(int choice) {

        if (choice == 1) {
            this.topColor = Color.blue;
            this.bottomColor = Color.yellow;

        }
        if (choice == 2) {
            this.topColor = Color.green;
            this.bottomColor = Color.red;
        }
        if (choice == 3) {
            this.topColor = Color.black;
            this.bottomColor = Color.white;
        }

        repaint();
    }

    public Color getTopColor() {
        return topColor;
    }

    public Color getBottomColor() {
        return bottomColor;
    }

    private void drawPicture(Graphics g) {

        for (int row = 0; row < picture.length; row++) {
            for (int col = 0; col < picture[0].length; col++) {
                if (picture[row][col] == 1) {
                    g.setColor(getTopColor());
                    g.fillRect(col * gridCellSize, row * gridCellSize, gridCellSize, gridCellSize);

                } else if (picture[row][col] == 2) {
                    g.setColor(getBottomColor());
                    g.fillRect(col * gridCellSize, row * gridCellSize, gridCellSize, gridCellSize);

                }
            }
        }

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int y = 0; y < gridRows; y++) {

            for (int x = 0; x < gridCols; x++) {
                {

                    g.drawRect(x * gridCellSize, y * gridCellSize, gridCellSize, gridCellSize);
                    //g.fillRect(y * gridCellSize, 0, gridCellSize, gridCellSize);

                }

            }
        }
        drawPicture(g);
    }
}
