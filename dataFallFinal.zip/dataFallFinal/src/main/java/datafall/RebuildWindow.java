/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datafall;

import blocks.IShape;
import blocks.JShape;
import blocks.LShape;
import blocks.OShape;
import blocks.SShape;
import blocks.TShape;
import blocks.ZShape;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

/**
 *
 * @author mac
 */
public class RebuildWindow extends JPanel {

    private Blocks block;
    private int gridRows;
    private int gridCols;
    private int gridCellSize;
    private Color[][] background;

    private Lines line; //= {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    private Blocks[] blocks;

    //private GameWindow gw;
    private Color color;
    private Color lineColor[] = new Color[10];

    //private Color[][] availableColors = new Color[10][10];
    private Color[][] availableColors = {{color.red, color.green, color.blue, color.red, color.green, color.blue, color.red, color.green, color.blue, color.blue}};

    public RebuildWindow(JPanel rebuildWinodwHold) {

        rebuildWinodwHold.setVisible(true);

        this.setBounds(rebuildWinodwHold.getBounds());
        this.setBackground(rebuildWinodwHold.getBackground());
        this.setBorder(rebuildWinodwHold.getBorder());

        gridCols = 10;
        gridCellSize = this.getBounds().width / gridCols;
        gridRows = this.getBounds().height / gridCellSize;

        background = new Color[gridRows][gridCols];
        
        background [1][1] = rebuildWinodwHold.getBackground();
        
        //color = line.getLineColor();

        //blocks = new Blocks[]{new IShape(),new JShape(),new TShape(),new ZShape(),new OShape(),new SShape(),new LShape()};
        //spawnBlock();
    }
}
      /*  public void printColors() {
       
       
            
        
    }
    
  

    public void spawnLine() {
        
        line = new Lines(new int[][]{{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}});
        
        line.spawn(gridCols);
        
        color = color.blue;

       
            //System.out.println(line.getLineColor());
       
    }

 public void drawLine(Graphics g) {
        Random rand = new Random();

        for (int row = 0; row < line.getRow(); row++) {
            for (int col = 0; col < line.getCol(); col++) {
                if (line.getLine()[row][col] == 1) {
                    {
                        //g.fillRect(col * gridCellSize, row * gridCellSize, gridCellSize, gridCellSize);
                        System.out.println(color);
                        //color = block.getLineColor();
                        //g.setColor(line.getColor());

                        //f (block.getClear() == true);
                       

                    }
                }

            }

        }
    }
     */
 /*   public void drawLine(Graphics g) {
        //
        //int h = line.getHeight();
        //int w = line.getWidth();
        //Color c = line.getColor();
        //int[][] shape = new int[][]{{1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

            /*for (int y = 0; y < gridRows; y++) {

                for (int x = 0; x < gridCols; x++) {
                    {

                        g.drawRect(x * gridCellSize, 0, gridCellSize, gridCellSize);
                        //g.fillRect(y * gridCellSize, 0, gridCellSize, gridCellSize);

                    }

                }
            
             for (int row = 0; row < h; row++) {
                for (int col = 0; col < w; col++) {
                //if (shape[row][col] == 1) {

                    //int x = (line.getX() + col) * gridCellSize;
                    int y = (line.getY() + row) * gridCellSize;

                    drawGridSquare(g, c, x, y);

                }

            }
        }
    }
      
   

    private void drawGridSquare(Graphics g, Color color, int x, int y) {
        g.setColor(color);
        g.fillRect(x, y, gridCellSize, gridCellSize);
        g.setColor(Color.black);
        g.drawRect(x, y, gridCellSize, gridCellSize);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawLine(g);

    }
}
*/

/*  public Color rebuild(Color input) {
        
      Color[] backgorundNew = new Color [10];
      
      
        
        for (int y = 0; y < gridRows; y++) {
            
            for (int x = 0; x < gridCols; x++) {
                //input = gw.rebuild(input[x]);     
                backgorundNew[x] = input;
                return input;
            }
        } 
    return Color.white;
   
}
 */
 /* private void drawCell(Graphics g){
 color = availableColors[rand.nextInt(availableColors.length)];
 Random rand = new Random();
       for (int row = 0; row < cell[0].length; row++)  {
          
            for(int col = 0; col < cell.length; col++){
                
                if (cell[col][row] == 1) {
                    
                   g.setColor(color);
                   //g.fillRect(col * gridCellSize, row * gridCellSize, gridCellSize, gridCellSize);
                   
                   //cell[col][row] = cell[col + 1][row];
                }
                
 }

 }
 }
 */
        